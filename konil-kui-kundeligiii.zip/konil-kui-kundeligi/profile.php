<?php
require_once 'auth.php';
require_login();
$user=current_user();
$q=db()->prepare('SELECT id,name,email,password,created_at FROM users WHERE id=?');
$q->execute([$user['id']]);
$account=$q->fetch();
if(!$account){ $_SESSION=[]; go('login.php'); }
$err=''; $saved=false;
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name=trim($_POST['name']??'');
  $email=strtolower(trim($_POST['email']??''));
  $current=$_POST['current_password']??'';
  $new=$_POST['new_password']??'';
  if(mb_strlen($name)<2 || !filter_var($email,FILTER_VALIDATE_EMAIL)) $err='Атыңызды және дұрыс email енгізіңіз.';
  elseif(!password_verify($current,$account['password'])) $err='Қазіргі құпиясөз дұрыс емес.';
  elseif($new!=='' && strlen($new)<8) $err='Жаңа құпиясөз кемінде 8 таңбадан тұруы керек.';
  else {
    try {
      if($new!=='') $q=db()->prepare('UPDATE users SET name=?,email=?,password=? WHERE id=?');
      else $q=db()->prepare('UPDATE users SET name=?,email=? WHERE id=?');
      if($new!=='') $q->execute([$name,$email,password_hash($new,PASSWORD_DEFAULT),$user['id']]);
      else $q->execute([$name,$email,$user['id']]);
      $_SESSION['user_name']=$name; $account['name']=$name; $account['email']=$email; $saved=true;
    } catch(PDOException $e){ $err=$e->getCode()==='23000'?'Бұл email басқа аккаунтта қолданылып жатыр.':'Профильді сақтау мүмкін болмады.'; }
  }
}
$title='Профиль'; require 'inc_header.php';
?>
<div class="page-intro"><div class="eyebrow">ЖЕКЕ КЕҢІСТІГІҢ</div><h1>Менің <em>профилім</em> ♡</h1><p>Аккаунтың туралы мәліметтерді осы жерден басқара аласың.</p></div>
<?php if($saved):?><div class="success">✓ Профиль сәтті жаңартылды.</div><?php endif;?>
<?php if($err):?><div class="alert"><?=e($err)?></div><?php endif;?>
<div class="profile-layout"><section class="profile-card"><div class="profile-avatar"><?=e(mb_strtoupper(mb_substr($account['name'],0,1)))?></div><h2><?=e($account['name'])?></h2><p><?=e($account['email'])?></p><span class="profile-since">✿ Аккаунт ашылған: <?=e(date('d.m.Y',strtotime($account['created_at'])))?></span></section>
<form class="form-card profile-form" method="post"><h2>Жеке мәліметтер</h2><label class="field-label">Есімің<input name="name" minlength="2" required value="<?=e($account['name'])?>"></label><label class="field-label">Email<input type="email" name="email" required value="<?=e($account['email'])?>"></label><div class="profile-separator"></div><h2>Құпиясөзді өзгерту</h2><p class="muted">Құпиясөзді ауыстырмасаң, жаңа құпиясөз өрісін бос қалдыр.</p><label class="field-label">Қазіргі құпиясөз<input type="password" name="current_password" required autocomplete="current-password" placeholder="Қазіргі құпиясөзің"></label><label class="field-label">Жаңа құпиясөз<input type="password" name="new_password" minlength="8" autocomplete="new-password" placeholder="Кемінде 8 таңба"></label><button class="btn primary">Өзгерістерді сақтау <span>→</span></button></form></div>
<?php require 'inc_footer.php'; ?>
