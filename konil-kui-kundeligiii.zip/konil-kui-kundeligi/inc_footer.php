<footer style="text-align:center;color:#aaa2b4;font-size:10px;padding:35px 0 0">✿ Ішкі әлем · Өзіңе қамқорлық жасауды ұмытпа.</footer>
</main></div></body></html>
