<?php
// MySQL баптауы. Файлдың көшірмесін config.php деп атап, деректерді енгізіңіз.
define('DB_HOST', 'localhost');
define('DB_NAME', 'mood_journal');
define('DB_USER', 'root');
define('DB_PASS', '');
