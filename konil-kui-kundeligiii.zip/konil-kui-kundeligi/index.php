<?php require_once 'auth.php'; if(logged_in()) go('dashboard.php'); else go('login.php');
