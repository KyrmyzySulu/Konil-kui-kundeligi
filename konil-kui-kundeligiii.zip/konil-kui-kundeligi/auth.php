<?php
if (session_status() === PHP_SESSION_NONE) { session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax']); session_start(); }
require_once __DIR__.'/api/db.php';
function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function logged_in(){ return !empty($_SESSION['user_id']); }
function require_login(){ if(!logged_in()){ header('Location: login.php'); exit; } }
function current_user(){ return ['id'=>$_SESSION['user_id']??0,'name'=>$_SESSION['user_name']??'']; }
function go($url){ header('Location: '.$url); exit; }
