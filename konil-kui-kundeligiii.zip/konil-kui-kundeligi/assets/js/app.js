const moods = {
  "Керемет": {emoji:"😄", hint:"Керемет! Осы қуанышты сәтті есте сақта. Бүгінгі жетістігіңді жазып қой.", color:"#e9b96e"},
  "Жақсы": {emoji:"😊", hint:"Жақсы күйіңді сақта. Өзіңе ұнайтын бір іспен айналыс.", color:"#91b99b"},
  "Қалыпты": {emoji:"😐", hint:"Қалыпты күн де — жақсы күн. Өзіңе кішкентай қуаныш сыйла.", color:"#a99ac8"},
  "Мұңды": {emoji:"😔", hint:"Өзіңе жұмсақ бол. Сенімді адаммен сөйлесіп, сезіміңді қағазға түсіріп көр.", color:"#8ca8c9"},
  "Шаршадым": {emoji:"😴", hint:"Денеңе демалыс керек болуы мүмкін. Су ішіп, үзіліс жасап, ертерек тынық.", color:"#9c9aab"},
  "Ашулы": {emoji:"😤", hint:"Бірнеше рет баяу тыныс ал. Аздап серуендеу немесе ойыңды жазу көмектесуі мүмкін.", color:"#d78f86"}
};
let selected = null;
const $ = id => document.getElementById(id);
let entriesCache = [];
async function loadEntries(){
  const response = await fetch('api/entries.php');
  if (!response.ok) throw new Error('Дерекқордан оқу қатесі');
  const rows = await response.json();
  entriesCache = rows.map(row => ({...row, date: row.created_at || row.date}));
  return entriesCache;
}
function dateText(date){return new Date(date).toLocaleString("kk-KZ",{day:"numeric",month:"long",year:"numeric",hour:"2-digit",minute:"2-digit"})}
function init(){
  $("todayLabel").textContent=new Date().toLocaleDateString("kk-KZ",{weekday:"long",day:"numeric",month:"long"});
  document.querySelectorAll(".mood-card").forEach(card=>card.addEventListener("click",()=>{
    document.querySelectorAll(".mood-card").forEach(c=>c.classList.remove("selected"));
    card.classList.add("selected");selected=card.dataset.mood;
    $("selectedEmoji").textContent=moods[selected].emoji;$("selectedTitle").textContent=selected;
    $("selectedHint").textContent=moods[selected].hint;$("saveMood").disabled=false;
  }));
  $("saveMood").addEventListener("click", async ()=>{
    if(!selected)return;
    const button=$("saveMood"); button.disabled=true;
    try {
      const response=await fetch('api/entries.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mood:selected,note:$("moodNote").value.trim(),score:Number(document.querySelector(".mood-card.selected").dataset.score)})});
      const result=await response.json(); if(!response.ok) throw new Error(result.error||'Сақтау қатесі');
      $("moodNote").value=""; selected=null;
      document.querySelectorAll(".mood-card").forEach(c=>c.classList.remove("selected"));
      $("selectedEmoji").textContent="♡";$("selectedTitle").textContent="Көңіл күйіңді таңда";$("selectedHint").textContent="Сезіміңді атау — өзіңді түсінудің алғашқы қадамы.";
      $("toast").textContent="Жазбаң дерекқорға сақталды ♡"; $("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2300); await render();
    } catch(error) { alert(error.message+'\nДерекқор баптауын тексер.'); button.disabled=false; }
  });
  $("clearEntries").addEventListener("click",async ()=>{if(confirm("Барлық күнделік жазбаларын өшіргің келе ме?")){try{const r=await fetch('api/entries.php',{method:'DELETE'});if(!r.ok)throw new Error();await render()}catch(e){alert('Өшіру мүмкін болмады. Дерекқорды тексер.')}}});
  render();
}
async function render(){
  let entries; try { entries=await loadEntries(); } catch(e) { $("journalList").innerHTML="Дерекқорға қосылу мүмкін болмады. Сервер мен MySQL баптауын тексер."; return; }$("totalCount").textContent=entries.length;
  $("lastMood").textContent=entries.length?moods[entries[0].mood].emoji+" "+entries[0].mood:"—";
  $("lastDate").textContent=entries.length?dateText(entries[0].date):"Әлі жазба жоқ";
  const avg=entries.length?entries.reduce((s,e)=>s+e.score,0)/entries.length:0;
  $("averageMood").textContent=entries.length?avg.toFixed(1)+"/5":"—";
  const list=$("journalList");
  if(!entries.length){list.innerHTML='<div class="empty-state"><span>📖</span><b>Күнделігің әзірге бос</b><p>Алғашқы көңіл күйіңді белгілеп, өз тарихыңды баста.</p></div>'}
  else{list.innerHTML=entries.slice(0,30).map(e=>`<article class="journal-entry"><span class="entry-emoji">${moods[e.mood].emoji}</span><div class="entry-body"><b>${escapeHtml(e.mood)}</b>${e.note?`<p>${escapeHtml(e.note)}</p>`:""}<small>${dateText(e.date)}</small></div></article>`).join("")}
  const chart=$("chartBars"),recent=entries.slice(0,7).reverse();
  if(!recent.length){chart.innerHTML='<div class="empty-chart">Алғашқы көңіл күйіңді белгілегенде график осында пайда болады ✨</div>';return}
  chart.innerHTML=recent.map(e=>`<div class="bar-wrap"><span class="bar-emoji">${moods[e.mood].emoji}</span><div class="bar" style="height:${e.score*18}%"></div><span class="bar-label">${new Date(e.date).toLocaleDateString("kk-KZ",{day:"numeric",month:"short"})}</span></div>`).join("");
}
function escapeHtml(str){return str.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
document.addEventListener("DOMContentLoaded",init);
