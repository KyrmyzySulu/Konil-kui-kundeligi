<?php
// Интерфейс тілі: қазақша (kk), орысша (ru), ағылшынша (en). Таңдау cookie-де сақталады.
const LANGS = ['kk'=>'Қазақша','ru'=>'Русский','en'=>'English'];

function lang(): string {
 static $l=null;
 if($l===null){ $c=$_COOKIE['lang']??'kk'; $l=isset(LANGS[$c])?$c:'kk'; }
 return $l;
}
function lang_dict(string $code): array {
 static $cache=[];
 if(!isset($cache[$code])){ $f=__DIR__.'/lang/'.$code.'.php'; $cache[$code]=is_file($f)?(require $f):[]; }
 return $cache[$code];
}
// Аударма жоқ болса — қазақша мәтін, ол да жоқ болса — кілттің өзі.
function t(string $key, ...$args): string {
 $s=lang_dict(lang())[$key]??lang_dict('kk')[$key]??$key;
 foreach($args as $i=>$a) $s=str_replace('{'.$i.'}',(string)$a,$s);
 return $s;
}
// JS-ке берілетін сөздік: "js." префиксі бар кілттер.
function lang_js(): array {
 $out=[]; $base=lang_dict('kk'); $cur=lang_dict(lang());
 foreach($base as $k=>$v){ if(strpos($k,'js.')===0) $out[substr($k,3)]=$cur[$k]??$v; }
 return $out;
}
