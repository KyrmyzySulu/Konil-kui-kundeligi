<?php require_once 'auth.php'; require_login(); $title=t('nav.settings'); require 'inc_header.php'; $g=user_gender()==='male'; $cur=lang(); ?>
<div class="page-intro"><div class="eyebrow"><?=e(t('set.eyebrow'))?></div><h1><?=e(t('set.h1a'))?><em><?=e(t('set.h1b'))?></em></h1><p><?=e(t('set.intro'))?></p></div>
<div class="set-wrap">
 <a class="set-back" href="profile.php">← <?=e(t('nav.profile'))?></a>
 <h2 class="set-h"><?=e(t('set.group1'))?></h2>
 <div class="set-card">
  <details class="set-row"><summary><i><svg viewBox="0 0 24 24"><path d="M6 8a6 6 0 1 1 12 0c0 7 3 8 3 8H3s3-1 3-8"/><path d="M10 20a2 2 0 0 0 4 0"/></svg></i><span><?=e(t('set.notif'))?></span><b class="chev"></b></summary>
   <div class="set-body"><label class="set-line"><span><?=e(t('set.remind'))?></span><input type="checkbox" id="remOn" class="set-switch"></label>
    <label class="set-line"><span><?=e(t('set.time'))?></span><input type="time" id="remTime" value="21:00"></label>
    <p class="set-note" id="remNote"><?=e(t('set.note'))?></p></div></details>
  <details class="set-row"><summary><i><svg viewBox="0 0 24 24"><path d="M12 3l8 3v6c0 5-3.500 8-8 9-4.500-1-8-4-8-9V6z"/><path d="M8.500 12l2.500 2.500 4.500-5"/></svg></i><span><?=e(t('set.perm'))?></span><b class="chev"></b></summary>
   <div class="set-body"><p class="set-note"><?=e(t('set.perm_state'))?> <b id="permState">—</b></p><button type="button" class="btn primary" id="permBtn"><?=e(t('set.perm'))?></button></div></details>
  <details class="set-row" id="langRow"><summary><i><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3c2.600 2.500 4 5.600 4 9s-1.400 6.500-4 9c-2.600-2.500-4-5.600-4-9s1.400-6.500 4-9z"/></svg></i><span><?=e(t('set.lang'))?></span><em class="set-val"><?=e(LANGS[$cur])?></em><b class="chev"></b></summary>
   <div class="set-body"><p class="set-note"><?=e(t('set.lang_note'))?></p>
    <form class="lang-opts" method="post" action="lang.php"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="back" value="settings.php">
     <?php foreach(LANGS as $code=>$name):?><button type="submit" name="lang" value="<?=e($code)?>" class="lang-opt<?=$code===$cur?' on':''?>"<?=$code===$cur?' aria-current="true"':''?>><b><?=e(strtoupper($code))?></b><span><?=e($name)?></span></button><?php endforeach;?>
    </form></div></details>
  <a class="set-row" href="profile.php"><span class="set-link"><i><svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.500 3.500-7 8-7s8 2.500 8 7"/></svg></i><span><?=e(t('set.profile'))?> (<?=e(t($g?'g.m':'g.f'))?>)</span><b class="chev"></b></span></a>
  <a class="set-row" href="export.php"><span class="set-link"><i><svg viewBox="0 0 24 24"><path d="M12 3v12m0 0l-4-4m4 4l4-4"/><path d="M4 20h16"/></svg></i><span><?=e(t('set.export'))?></span><b class="chev"></b></span></a>
 </div>
 <h2 class="set-h"><?=e(t('set.group2'))?></h2>
 <div class="set-card">
  <details class="set-row"><summary><i><svg viewBox="0 0 24 24"><path d="M4 5h16v11H9l-5 4z"/><path d="M9 10h6"/></svg></i><span><?=e(t('set.faq'))?></span><b class="chev"></b></summary>
   <div class="set-body"><p><b><?=e(t('set.faq1q'))?></b><br><?=e(t('set.faq1a'))?></p><p><b><?=e(t('set.faq2q'))?></b><br><?=e(t('set.faq2a'))?></p><p><b><?=e(t('set.faq3q'))?></b><br><?=e(t('set.faq3a'))?></p></div></details>
  <details class="set-row"><summary><i><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16.500v.5"/></svg></i><span><?=e(t('set.about'))?></span><b class="chev"></b></summary>
   <div class="set-body"><p><?=e(t('set.about_txt'))?></p></div></details>
  <a class="set-row" href="logout.php" onclick="document.getElementById('logoutForm').submit();return false"><span class="set-link danger"><i><svg viewBox="0 0 24 24"><path d="M9 4H5v16h4"/><path d="M16 8l4 4-4 4M20 12H9"/></svg></i><span><?=e(t('set.logout'))?></span><b class="chev"></b></span></a>
 </div>
</div>
<script>
(()=>{const u=window.YEN_UID,K='remind:'+u,$=id=>document.getElementById(id);
let c={on:false,t:'21:00'};try{c=Object.assign(c,JSON.parse(localStorage.getItem(K)||'{}'))}catch(e){}
$('remOn').checked=c.on;$('remTime').value=c.t;
const save=()=>{c={on:$('remOn').checked,t:$('remTime').value||'21:00'};try{localStorage.setItem(K,JSON.stringify(c))}catch(e){}};
$('remOn').onchange=()=>{save();if(c.on&&'Notification' in window&&Notification.permission==='default')Notification.requestPermission().then(perm)};
$('remTime').onchange=save;
const names=<?=json_encode(['granted'=>t('set.perm_granted'),'denied'=>t('set.perm_denied'),'default'=>t('set.perm_default')],JSON_UNESCAPED_UNICODE|JSON_HEX_TAG)?>,none=<?=json_encode(t('set.perm_none'),JSON_UNESCAPED_UNICODE|JSON_HEX_TAG)?>;
function perm(){$('permState').textContent=('Notification' in window)?names[Notification.permission]:none}
$('permBtn').onclick=()=>{if('Notification' in window)Notification.requestPermission().then(perm)};perm();})();
</script>
<?php require 'inc_footer.php'; ?>
