USE mood_journal;
ALTER TABLE users ADD COLUMN gender ENUM('female','male') NOT NULL DEFAULT 'female';
