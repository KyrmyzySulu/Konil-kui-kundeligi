<?php
require_once 'auth.php'; require_login(); csrf_check();
$id=(int)($_GET['id']??0); $q=db()->prepare('SELECT * FROM mood_entries WHERE id=? AND user_id=?'); $q->execute([$id,current_user()['id']]); $entry=$q->fetch(); if(!$entry){http_response_code(404);exit(t('edit.nf'));}
$moods=mood_scores(); $err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $m=$_POST['mood']??''; $note=trim($_POST['note']??''); $date=$_POST['entry_date']??''; $category=cat_store($_POST['category']??'');
 if(!isset($moods[$m]) || !valid_date($date)) $err=t('add.err');
 else {$q=db()->prepare('UPDATE mood_entries SET mood=?,score=?,note=?,category=?,entry_date=? WHERE id=? AND user_id=?');$q->execute([$m,$moods[$m],$note,$category,$date,$id,current_user()['id']]);go('history.php?updated=1');}
}
$title=t('hist.edit'); require 'inc_header.php'; ?>
<div class="page-intro"><div class="eyebrow"><?=e(t('edit.eyebrow'))?></div><h1><?=e(t('edit.h1a'))?><em><?=e(t('edit.h1b'))?></em></h1></div>
<?php if($err):?><div class="alert"><?=e($err)?></div><?php endif;?>
<form class="form-card" method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><h2><?=e(t('edit.mood'))?></h2><div class="mood-grid"><?php foreach($moods as $m=>$score):?><label class="mood-option"><input type="radio" name="mood" value="<?=e($m)?>" <?=$entry['mood']===$m?'checked':''?> required><span class="mood-face"><?=mood_face($m)?></span><b><?=e(mood_name($m))?></b></label><?php endforeach;?></div><label class="field-label"><?=e(t('add.category'))?><input name="category" value="<?=e(cat_name($entry['category']??''))?>" maxlength="60"></label><label class="field-label"><?=e(t('edit.about'))?><textarea name="note" rows="5"><?=e($entry['note'])?></textarea></label><label class="field-label"><?=e(t('add.date'))?><input type="date" name="entry_date" value="<?=e($entry['entry_date'])?>" required></label><button class="btn primary"><?=e(t('edit.save'))?> →</button></form><?php require 'inc_footer.php'; ?>