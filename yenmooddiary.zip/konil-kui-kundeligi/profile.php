<?php
require_once 'auth.php'; require_login(); csrf_check(); $user=current_user();
$q=db()->prepare('SELECT * FROM users WHERE id=?');$q->execute([$user['id']]);$account=$q->fetch();if(!$account){$_SESSION=[];go('login.php');}
$err='';$saved=isset($_GET['saved']);
if($_SERVER['REQUEST_METHOD']==='POST'){
 $name=trim($_POST['name']??'');$email=strtolower(trim($_POST['email']??''));$current=$_POST['current_password']??'';$new=$_POST['new_password']??'';$gender=$_POST['gender']??($account['gender']??'female');$avatar=$account['avatar']??null;
 if(mb_strlen($name)<2 || !filter_var($email,FILTER_VALIDATE_EMAIL) || !in_array($gender,['female','male'],true))$err=t('pf.err_basic');
 elseif(!password_verify($current,$account['password']))$err=t('pf.err_pass');
 elseif($new!=='' && strlen($new)<8)$err=t('pf.err_new');
 else {
  if(isset($_FILES['avatar']) && $_FILES['avatar']['error']!==UPLOAD_ERR_NO_FILE){
   $f=$_FILES['avatar'];$allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
   if($f['error']!==UPLOAD_ERR_OK || $f['size']>2*1024*1024)$err=t('pf.err_size');
   else {$info=@getimagesize($f['tmp_name']);$mime=$info['mime']??'';if(!$info || !isset($allowed[$mime]))$err=t('pf.err_type');
    else {$dir=__DIR__.'/uploads/avatars';if(!is_dir($dir))mkdir($dir,0755,true);$filename='user_'.$user['id'].'_'.bin2hex(random_bytes(6)).'.'.$allowed[$mime];if(move_uploaded_file($f['tmp_name'],$dir.'/'.$filename))$avatar='uploads/avatars/'.$filename;else $err=t('pf.err_upload');}
   }
  }
  if(!$err){try{if($new!==''){$q=db()->prepare('UPDATE users SET name=?,email=?,password=?,avatar=?,gender=? WHERE id=?');$q->execute([$name,$email,password_hash($new,PASSWORD_DEFAULT),$avatar,$gender,$user['id']]);}else{$q=db()->prepare('UPDATE users SET name=?,email=?,avatar=?,gender=? WHERE id=?');$q->execute([$name,$email,$avatar,$gender,$user['id']]);}
   $_SESSION['user_name']=$name;$account['name']=$name;$account['email']=$email;$account['avatar']=$avatar;$account['gender']=$gender;go('profile.php?saved=1');
  }catch(PDOException $e){$err=$e->getCode()==='23000'?t('pf.err_dup'):t('pf.err_save');}}
 }
}
$title=t('nav.profile');require 'inc_header.php';
$avatarUrl=!empty($account['avatar']) && is_file(__DIR__.'/'.$account['avatar'])?$account['avatar']:(($account['gender']??'female')==='male'?'assets/images/avatar-boy.png':'assets/images/avatar-girl.png');
?>
<div class="page-intro"><div class="eyebrow"><?=e(t('pf.eyebrow'))?></div><h1><?=e(t('pf.h1a'))?><em><?=e(t('pf.h1b'))?></em> ♡</h1><p><?=e(t('pf.intro'))?></p></div>
<?php if($saved):?><div class="success"><?=e(t('pf.saved'))?></div><?php endif;?><?php if($err):?><div class="alert"><?=e($err)?></div><?php endif;?>
<div class="profile-layout">
 <section class="profile-card profile-preview-card">
  <div class="profile-preview-wrap">
   <img id="avatarPreview" class="profile-avatar-img" src="<?=e($avatarUrl)?>" alt="<?=e(t('pf.alt'))?>">
   <span class="avatar-camera">＋</span>
  </div>
  <h2><?=e($account['name'])?></h2><p><?=e($account['email'])?></p>
  <span class="profile-since"><?=e(t('pf.since'))?> <?=e(date('d.m.Y',strtotime($account['created_at'])))?></span>
  <small class="avatar-help"><?=e(t('pf.help'))?></small>
  <a class="profile-settings" href="settings.php"><i><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.400 15a1.700 1.700 0 0 0 .3 1.800l.1.100a2 2 0 1 1-2.800 2.800l-.1-.1a1.700 1.700 0 0 0-1.800-.3 1.700 1.700 0 0 0-1 1.500V21a2 2 0 1 1-4 0v-.1a1.700 1.700 0 0 0-1.100-1.500 1.700 1.700 0 0 0-1.800.3l-.1.100a2 2 0 1 1-2.800-2.800l.1-.1a1.700 1.700 0 0 0 .3-1.800 1.700 1.700 0 0 0-1.500-1H3a2 2 0 1 1 0-4h.1a1.700 1.700 0 0 0 1.500-1.100 1.700 1.700 0 0 0-.3-1.800l-.1-.1a2 2 0 1 1 2.800-2.800l.1.1a1.700 1.700 0 0 0 1.800.3H9a1.700 1.700 0 0 0 1-1.500V3a2 2 0 1 1 4 0v.1a1.700 1.700 0 0 0 1 1.500 1.700 1.700 0 0 0 1.800-.3l.1-.1a2 2 0 1 1 2.800 2.800l-.1.100a1.700 1.700 0 0 0-.3 1.800V9a1.700 1.700 0 0 0 1.500 1H21a2 2 0 1 1 0 4h-.1a1.700 1.700 0 0 0-1.500 1z"/></svg></i><span><b><?=e(t('pf.settings'))?></b><small><?=e(t('pf.settings_sub'))?></small></span><em>›</em></a>
 </section>
 <form class="form-card profile-form" method="post" enctype="multipart/form-data">
  <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
  <h2><?=e(t('pf.details'))?></h2>
  <label class="avatar-upload-box" for="avatarInput"><span class="upload-symbol">↑</span><b><?=e(t('pf.pick'))?></b><small id="avatarFileName"><?=e(t('pf.pick_sub'))?></small><input id="avatarInput" type="file" name="avatar" accept="image/jpeg,image/png,image/webp"></label>
  <label class="field-label"><?=e(t('pf.name'))?><input name="name" minlength="2" required value="<?=e($account['name'])?>"></label>
  <label class="field-label">Email<input type="email" name="email" required value="<?=e($account['email'])?>"></label>
  <?=gender_picker($account['gender']??'female')?><div class="profile-separator"></div><h2><?=e(t('pf.pw_h'))?></h2><p class="muted"><?=e(t('pf.pw_muted'))?></p>
  <label class="field-label"><?=e(t('pf.cur'))?><input type="password" name="current_password" required autocomplete="current-password" placeholder="<?=e(t('pf.cur'))?>"></label>
  <label class="field-label"><?=e(t('pf.new'))?><input type="password" name="new_password" minlength="8" autocomplete="new-password" placeholder="<?=e(t('pf.new_ph'))?>"></label>
  <button class="btn primary"><?=e(t('pf.save'))?> <span>→</span></button>
 </form>
</div>
<script>
(()=>{const input=document.getElementById('avatarInput'),preview=document.getElementById('avatarPreview'),name=document.getElementById('avatarFileName');let custom=false;document.querySelectorAll('input[name="gender"]').forEach(r=>r.addEventListener('change',()=>{if(!custom)preview.src=r.value==='male'?'assets/images/avatar-boy.png':'assets/images/avatar-girl.png'}));if(!input)return;input.addEventListener('change',()=>{const file=input.files[0];if(!file)return;if(!/^image\/(jpeg|png|webp)$/.test(file.type)||file.size>2*1024*1024){alert(<?=json_encode(t('pf.js_alert'),JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS)?>);input.value='';return;}preview.src=URL.createObjectURL(file);custom=true;name.textContent=file.name;});})();
</script>
<?php require 'inc_footer.php'; ?>
