<?php
// Шығу тек POST + CSRF токенімен орындалады (GET арқылы сілтемемен шығарып жіберуге болмайды).
require_once 'auth.php';
if(!logged_in()) go('login.php');
if($_SERVER['REQUEST_METHOD']!=='POST'){
 // JS өшірулі болса: растау батырмасы бар қарапайым бет. GET шығармайды.
 ?><!doctype html><html lang="<?=e(lang())?>"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e(t('nav.logout'))?> · <?=e(t('app.name'))?></title><link rel="stylesheet" href="assets/css/style.css"></head><body class="auth-page"><div class="auth-card"><form method="post" action="logout.php"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><button class="btn primary full"><?=e(t('nav.logout'))?></button></form><p class="auth-foot"><a href="dashboard.php">←</a></p></div></body></html><?php
 exit;
}
csrf_check();
$_SESSION=[];
if(ini_get('session.use_cookies')){ $p=session_get_cookie_params(); setcookie(session_name(),'',['expires'=>time()-42000,'path'=>$p['path'],'domain'=>$p['domain'],'secure'=>$p['secure'],'httponly'=>$p['httponly'],'samesite'=>'Lax']); }
session_destroy();
go('login.php');
