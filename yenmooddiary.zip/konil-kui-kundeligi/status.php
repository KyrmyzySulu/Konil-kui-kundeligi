<?php
require_once 'auth.php'; require_login(); require_once 'inc_status.php';
$title=t('nav.status'); $extra_css=['assets/css/status.css?v=5'];
$state=status_load((int)current_user()['id']);
require 'inc_header.php';
$J=JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE;
?>
<div class="sx-top">
 <div class="sx-hello"><div class="page-intro"><div class="eyebrow"><?=e(t('st.eyebrow'))?></div><h1><?=e(t('st.h1a'))?><em><?=e(t('st.h1b'))?></em></h1><p><?=e(t('st.sub'))?></p><div class="sx-now"><?=e(t('st.today'))?> <b id="sxClock">--:--</b></div></div></div>
 <div class="sx-widgets"><div class="sx-w sx-ring" id="sxRing"></div><div class="sx-w sx-water" id="sxWater"></div><div class="cd-card cd-bd sx-bd" id="holBd"></div></div>
</div>
<div class="sx-grid">
 <section class="sx-card sx-me" id="sxMe" aria-label="<?=e(t('st.aria_me'))?>"></section>
 <section class="sx-card sx-pet" id="sxPet" aria-label="<?=e(t('st.aria_pet'))?>"></section>
</div>
<script>window.YEN_STATE=<?=json_encode($state,$J)?>;window.YEN_CSRF=<?=json_encode(csrf_token(),$J)?>;window.YEN_T=<?=json_encode(lang_js(),$J)?>;</script>
<script>
(()=>{
const T=(k,...a)=>{let s=(window.YEN_T||{})[k];if(s==null)s=k;a.forEach((v,i)=>{s=s.split('{'+i+'}').join(v)});return s};
const PS={"cat": "<path d=\"M22 52 L18 14 L50 34 Z\" fill=\"#fff3df\" stroke=\"#2b2230\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path d=\"M98 52 L102 14 L70 34 Z\" fill=\"#fff3df\" stroke=\"#2b2230\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path d=\"M25 42 L24 26 L37 34 Z\" fill=\"#f7b6bf\"/><path d=\"M95 42 L96 26 L83 34 Z\" fill=\"#f7b6bf\"/><ellipse cx=\"60\" cy=\"58\" rx=\"44\" ry=\"34\" fill=\"#fff3df\" stroke=\"#2b2230\" stroke-width=\"4\"/><path d=\"M60 26 v8 M50 28 l2 7 M70 28 l-2 7\" stroke=\"#c98a55\" stroke-width=\"4\" stroke-linecap=\"round\"/><g class=\"eyes-closed\"><path d=\"M38 60q6-8 12 0M70 60q6-8 12 0\" fill=\"none\" stroke=\"#2b2230\" stroke-width=\"3.5\" stroke-linecap=\"round\"/></g><g class=\"eyes\"><ellipse cx=\"44\" cy=\"58\" rx=\"4.5\" ry=\"6\" fill=\"#2b2230\"/><ellipse cx=\"76\" cy=\"58\" rx=\"4.5\" ry=\"6\" fill=\"#2b2230\"/><circle cx=\"45.5\" cy=\"56\" r=\"1.8\" fill=\"#fff\"/><circle cx=\"77.5\" cy=\"56\" r=\"1.8\" fill=\"#fff\"/></g><ellipse cx=\"33\" cy=\"68\" rx=\"7\" ry=\"4.5\" fill=\"#f7a8b4\" opacity=\".7\"/><ellipse cx=\"87\" cy=\"68\" rx=\"7\" ry=\"4.5\" fill=\"#f7a8b4\" opacity=\".7\"/><path d=\"M57 66 h6 l-3 4 z\" fill=\"#f08aa0\"/><path d=\"M60 70 v3 M60 73 q-5 5 -9 1 M60 73 q5 5 9 1\" stroke=\"#2b2230\" stroke-width=\"3\" fill=\"none\" stroke-linecap=\"round\"/><ellipse cx=\"36\" cy=\"92\" rx=\"13\" ry=\"7\" fill=\"#fff3df\" stroke=\"#2b2230\" stroke-width=\"4\"/><ellipse cx=\"84\" cy=\"92\" rx=\"13\" ry=\"7\" fill=\"#fff3df\" stroke=\"#2b2230\" stroke-width=\"4\"/>", "dog": "<path d=\"M16 30 Q2 44 10 72 Q24 74 34 56 Z\" fill=\"#c98a55\" stroke=\"#2b2230\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path d=\"M104 30 Q118 44 110 72 Q96 74 86 56 Z\" fill=\"#c98a55\" stroke=\"#2b2230\" stroke-width=\"4\" stroke-linejoin=\"round\"/><ellipse cx=\"60\" cy=\"56\" rx=\"40\" ry=\"34\" fill=\"#ffe4bd\" stroke=\"#2b2230\" stroke-width=\"4\"/><path d=\"M60 24 q-12 6 -10 18 q10 6 20 0 q2 -12 -10 -18z\" fill=\"#c98a55\" opacity=\".35\"/><g class=\"eyes-closed\"><path d=\"M38 54q6-8 12 0M70 54q6-8 12 0\" fill=\"none\" stroke=\"#2b2230\" stroke-width=\"3.5\" stroke-linecap=\"round\"/></g><g class=\"eyes\"><ellipse cx=\"44\" cy=\"52\" rx=\"4.5\" ry=\"6\" fill=\"#2b2230\"/><ellipse cx=\"76\" cy=\"52\" rx=\"4.5\" ry=\"6\" fill=\"#2b2230\"/><circle cx=\"45.5\" cy=\"50\" r=\"1.8\" fill=\"#fff\"/><circle cx=\"77.5\" cy=\"50\" r=\"1.8\" fill=\"#fff\"/></g><ellipse cx=\"60\" cy=\"68\" rx=\"19\" ry=\"14\" fill=\"#fff6e6\" stroke=\"#2b2230\" stroke-width=\"3.5\"/><ellipse cx=\"60\" cy=\"62\" rx=\"7\" ry=\"5\" fill=\"#2b2230\"/><path d=\"M60 67 v5 M60 72 q-6 6 -11 1 M60 72 q6 6 11 1\" stroke=\"#2b2230\" stroke-width=\"3\" fill=\"none\" stroke-linecap=\"round\"/><path d=\"M54 80 q6 12 12 0 z\" fill=\"#f08aa0\" stroke=\"#2b2230\" stroke-width=\"2.5\" stroke-linejoin=\"round\"/><ellipse cx=\"30\" cy=\"64\" rx=\"6\" ry=\"4\" fill=\"#f7a8b4\" opacity=\".7\"/><ellipse cx=\"90\" cy=\"64\" rx=\"6\" ry=\"4\" fill=\"#f7a8b4\" opacity=\".7\"/><ellipse cx=\"38\" cy=\"92\" rx=\"13\" ry=\"7\" fill=\"#ffe4bd\" stroke=\"#2b2230\" stroke-width=\"4\"/><ellipse cx=\"82\" cy=\"92\" rx=\"13\" ry=\"7\" fill=\"#ffe4bd\" stroke=\"#2b2230\" stroke-width=\"4\"/>", "bunny": "<g class=\"ears\"><ellipse cx=\"44\" cy=\"26\" rx=\"12\" ry=\"26\" fill=\"#fff\" stroke=\"#2b2230\" stroke-width=\"4\"/><ellipse cx=\"44\" cy=\"28\" rx=\"5.5\" ry=\"17\" fill=\"#f7b6bf\"/><ellipse cx=\"76\" cy=\"26\" rx=\"12\" ry=\"26\" fill=\"#fff\" stroke=\"#2b2230\" stroke-width=\"4\"/><ellipse cx=\"76\" cy=\"28\" rx=\"5.5\" ry=\"17\" fill=\"#f7b6bf\"/></g><ellipse cx=\"60\" cy=\"78\" rx=\"38\" ry=\"30\" fill=\"#fff\" stroke=\"#2b2230\" stroke-width=\"4\"/><g class=\"eyes-closed\"><path d=\"M40 78q6-8 12 0M68 78q6-8 12 0\" fill=\"none\" stroke=\"#2b2230\" stroke-width=\"3.5\" stroke-linecap=\"round\"/></g><g class=\"eyes\"><ellipse cx=\"46\" cy=\"76\" rx=\"4.5\" ry=\"6\" fill=\"#2b2230\"/><ellipse cx=\"74\" cy=\"76\" rx=\"4.5\" ry=\"6\" fill=\"#2b2230\"/><circle cx=\"47.5\" cy=\"74\" r=\"1.8\" fill=\"#fff\"/><circle cx=\"75.5\" cy=\"74\" r=\"1.8\" fill=\"#fff\"/></g><ellipse cx=\"35\" cy=\"87\" rx=\"6.5\" ry=\"4\" fill=\"#f7a8b4\" opacity=\".75\"/><ellipse cx=\"85\" cy=\"87\" rx=\"6.5\" ry=\"4\" fill=\"#f7a8b4\" opacity=\".75\"/><path d=\"M57 84 h6 l-3 4 z\" fill=\"#f08aa0\"/><path d=\"M60 88 v3 M60 91 q-5 5 -9 1 M60 91 q5 5 9 1\" stroke=\"#2b2230\" stroke-width=\"3\" fill=\"none\" stroke-linecap=\"round\"/><ellipse cx=\"40\" cy=\"110\" rx=\"12\" ry=\"7\" fill=\"#fff\" stroke=\"#2b2230\" stroke-width=\"4\"/><ellipse cx=\"80\" cy=\"110\" rx=\"12\" ry=\"7\" fill=\"#fff\" stroke=\"#2b2230\" stroke-width=\"4\"/>"};
const PLACES=[
{id:'home',name:'Үй',c:'#f2b36f',deco:`<rect width="400" height="300" fill="#fde7c4"/><rect x="36" y="40" width="112" height="94" rx="12" fill="#c58555"/><rect x="44" y="48" width="96" height="78" rx="8" fill="#bfe4ff"/><path d="M92 48v78M44 87h96" stroke="#c58555" stroke-width="5"/><circle cx="64" cy="68" r="9" fill="#ffe27a"/><rect x="250" y="70" width="110" height="10" rx="5" fill="#c58555"/><rect x="262" y="40" width="14" height="30" rx="3" fill="#8fb9e8"/><rect x="280" y="48" width="14" height="22" rx="3" fill="#f2a5b5"/><path d="M326 70h30l-4-26h-22z" fill="#d9644f"/><path d="M341 44q-10-16-20-10M341 44q4-18 14-14" stroke="#4f9a4a" stroke-width="4" fill="none"/><rect y="236" width="400" height="64" fill="#e8a56a"/><path d="M0 262H400" stroke="#d9904f" stroke-width="3"/><ellipse cx="200" cy="264" rx="150" ry="22" fill="#ffe08a" stroke="#f2c25a" stroke-width="3"/>`},
{id:'meadow',name:'Дала',c:'#7fcf8a',deco:`<defs><linearGradient id="ptsky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9fdcf6"/><stop offset="1" stop-color="#e5f6c8"/></linearGradient></defs><rect width="400" height="300" fill="url(#ptsky)"/><circle cx="330" cy="58" r="30" fill="#fff3b0"/><ellipse cx="90" cy="60" rx="42" ry="13" fill="#fff" opacity=".9"/><ellipse cx="130" cy="72" rx="30" ry="10" fill="#fff" opacity=".9"/><path d="M0 200Q100 150 200 195T400 180V300H0z" fill="#8fd98f"/><path d="M0 240Q150 210 400 235V300H0z" fill="#6fc97c"/><g><circle cx="50" cy="262" r="6" fill="#ff8fb8"/><circle cx="90" cy="278" r="6" fill="#ffd36e"/><circle cx="330" cy="268" r="6" fill="#ff8fb8"/><circle cx="360" cy="284" r="6" fill="#fff"/><circle cx="290" cy="280" r="6" fill="#ffd36e"/></g>`},
{id:'cafe',name:'Кафе',c:'#7a9f84',deco:`<rect width="400" height="300" fill="#f3dcb8"/><path d="M0 0h50v52q-25 16-50 0z" fill="#4f7a5c"/><path d="M50 0h50v52q-25 16-50 0z" fill="#e7eee4"/><path d="M100 0h50v52q-25 16-50 0z" fill="#4f7a5c"/><path d="M150 0h50v52q-25 16-50 0z" fill="#e7eee4"/><path d="M200 0h50v52q-25 16-50 0z" fill="#4f7a5c"/><path d="M250 0h50v52q-25 16-50 0z" fill="#e7eee4"/><path d="M300 0h50v52q-25 16-50 0z" fill="#4f7a5c"/><path d="M350 0h50v52q-25 16-50 0z" fill="#e7eee4"/><rect x="40" y="90" width="90" height="100" rx="10" fill="#ffffff66"/><rect x="270" y="90" width="90" height="100" rx="10" fill="#ffffff66"/><path d="M200 52v30" stroke="#7b5a3c" stroke-width="3"/><path d="M184 98q16-30 32 0z" fill="#ffd36e"/><rect y="226" width="400" height="12" fill="#b98a5e"/><rect y="238" width="400" height="62" fill="#8a6a4c"/><path d="M0 268H400" stroke="#775a3f" stroke-width="3"/><rect x="300" y="196" width="22" height="30" rx="6" fill="#fff"/><path d="M322 204q10 0 10 8t-10 8" fill="none" stroke="#fff" stroke-width="4"/>`},
{id:'newyear',name:'Жаңа жыл',c:'#4b5fb0',deco:`<defs><linearGradient id="ptny" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#16204f"/><stop offset="1" stop-color="#3a4a96"/></linearGradient></defs><rect width="400" height="300" fill="url(#ptny)"/><circle cx="40" cy="40" r="2" fill="#fff" opacity=".85"/><circle cx="120" cy="24" r="2.5" fill="#fff" opacity=".85"/><circle cx="210" cy="50" r="2" fill="#fff" opacity=".85"/><circle cx="300" cy="28" r="3" fill="#fff" opacity=".85"/><circle cx="350" cy="80" r="2" fill="#fff" opacity=".85"/><circle cx="80" cy="100" r="2" fill="#fff" opacity=".85"/><path d="M0 240Q100 214 200 236T400 228V300H0z" fill="#f4f8ff"/><path d="M300 236l32-70l32 70z" fill="#2f8f5c"/><path d="M306 206l26-56l26 56z" fill="#3aa56c"/><path d="M332 132l5 10 11 1-8 8 2 11-10-6-10 6 2-11-8-8 11-1z" fill="#ffd36e"/><circle cx="322" cy="196" r="4" fill="#ff5f7a"/><circle cx="344" cy="214" r="4" fill="#ffd36e"/><circle cx="326" cy="226" r="4" fill="#7de3ff"/><rect x="44" y="238" width="38" height="32" rx="4" fill="#e8445a"/><path d="M63 238v32M44 254h38" stroke="#ffe27a" stroke-width="5"/><rect x="86" y="250" width="28" height="22" rx="4" fill="#5ba3e0"/><path d="M100 250v22" stroke="#fff" stroke-width="4"/><g><circle class="pt-snow" style="animation-delay:-0.0s" cx="20" cy="0" r="2" fill="#fff"/><circle class="pt-snow" style="animation-delay:-0.7s" cx="57" cy="0" r="3" fill="#fff"/><circle class="pt-snow" style="animation-delay:-1.4s" cx="94" cy="0" r="4" fill="#fff"/><circle class="pt-snow" style="animation-delay:-2.0999999999999996s" cx="131" cy="0" r="2" fill="#fff"/><circle class="pt-snow" style="animation-delay:-2.8s" cx="168" cy="0" r="3" fill="#fff"/><circle class="pt-snow" style="animation-delay:-3.5s" cx="205" cy="0" r="4" fill="#fff"/><circle class="pt-snow" style="animation-delay:-4.199999999999999s" cx="242" cy="0" r="2" fill="#fff"/><circle class="pt-snow" style="animation-delay:-4.8999999999999995s" cx="279" cy="0" r="3" fill="#fff"/><circle class="pt-snow" style="animation-delay:-5.6s" cx="316" cy="0" r="4" fill="#fff"/><circle class="pt-snow" style="animation-delay:-6.3s" cx="353" cy="0" r="2" fill="#fff"/><circle class="pt-snow" style="animation-delay:-7.0s" cx="390" cy="0" r="3" fill="#fff"/></g>`},
{id:'beach',name:'Жағажай',c:'#4fb6e8',deco:`<rect width="400" height="300" fill="#a6e0f7"/><circle cx="64" cy="58" r="28" fill="#fff3b0"/><rect y="130" width="400" height="80" fill="#4fb6e8"/><path d="M0 150q25-10 50 0t50 0 50 0 50 0 50 0 50 0 50 0 50 0" stroke="#bfe9ff" stroke-width="4" fill="none"/><path d="M0 206Q200 184 400 206V300H0z" fill="#f6d9a0"/><path d="M310 230v-70" stroke="#8a5a3c" stroke-width="5"/><path d="M270 168q40-44 80 0z" fill="#ff8f86"/><path d="M290 168q20-30 20 0M310 168q0-34 20 0" fill="#fff" opacity=".7"/><circle cx="90" cy="268" r="7" fill="#ffb3c7"/><path d="M130 280q8-10 16 0z" fill="#fff"/>`}
];
const ACT={feed:{n:'Тамақтандыру',s:'Тамақ',v:'тамақтанып жатыр'},sleep:{n:'Ұйықтату',s:'Ұйқы',v:'ұйықтап жатыр'},play:{n:'Ойнату',s:'Ойын',v:'ойнап жатыр'},bath:{n:'Жуындыру',s:'Жуыну',v:'жуынып жатыр'},cuddle:{n:'Сыйпау',s:'Сыйпау',v:'сыйпалып жатыр'}};
const PN={cat:'Мур',dog:'Тобик',bunny:'Қоянша'};
const DIM={cat:[130,104,'0 0 120 96','#fff3df'],dog:[130,104,'0 0 120 96','#ffe4bd'],bunny:[112,112,'0 0 120 120','#fff']};
const SAY={cat:{feed:'Ам-ам-ам! Дәмді!',sleep:'Zzz… тәтті түс',play:'Мяу! Тағы лақтыр!',bath:'Көбік жұмсақ екен!',cuddle:'Мур-мур… тағы сыйпа'},dog:{feed:'Гав! Қарным ашып еді!',sleep:'Zzz… сүйек түсімде',play:'Гав-гав! Қуып жетемін!',bath:'Шашырап кеттім!',cuddle:'Гав… мен сені жақсы көрем'},bunny:{feed:'Сәбіз қандай тәтті!',sleep:'Zzz… бұлт үстінде жүрмін',play:'Секіре берем!',bath:'Құлағыма су кетпесін!',cuddle:'Тақ-тақ… жұмсақ'}};

function pre(){return pet.act==='sleep'?'<rect width="400" height="300" fill="#141a4a" opacity=".5"/>':''}
function post(){switch(pet.act){
 case 'feed':return '<path d="M150 262h100q-6 28-50 28q-44 0-50-28z" fill="#ff8f86" stroke="#2b2230" stroke-width="4" stroke-linejoin="round"/><ellipse cx="200" cy="262" rx="50" ry="9" fill="#c98a55" stroke="#2b2230" stroke-width="4"/><g fill="#7a4a2c"><circle cx="180" cy="260" r="4"/><circle cx="197" cy="257" r="4"/><circle cx="214" cy="260" r="4"/><circle cx="226" cy="257" r="3.5"/></g><text class="pt-fl" x="262" y="196" font-size="24" fill="#ff6f9c">♥</text><text class="pt-fl d2" x="128" y="204" font-size="18" fill="#ffd36e">♥</text>';
 case 'sleep':return '<path d="M142 236h116a10 10 0 0 1 10 10v36H132v-36a10 10 0 0 1 10-10z" fill="#a9c4ff" stroke="#2b2230" stroke-width="4" stroke-linejoin="round"/><path d="M150 252h100M150 266h100" stroke="#fff" stroke-opacity=".6" stroke-width="4" stroke-linecap="round"/><g fill="#fff" font-weight="800"><text class="pt-fl" x="262" y="170" font-size="30">z</text><text class="pt-fl d2" x="284" y="146" font-size="22">z</text><text class="pt-fl d3" x="300" y="126" font-size="16">z</text></g><path d="M330 40a24 24 0 1 0 18 40a19 19 0 1 1-18-40z" fill="#ffe9a8"/>';
 case 'play':return '<g class="pt-ball"><circle cx="294" cy="244" r="17" fill="#ff6f8f" stroke="#2b2230" stroke-width="4"/><path d="M279 240q15 7 30 0" fill="none" stroke="#fff" stroke-width="3"/></g><circle cx="108" cy="250" r="14" fill="#8fd0ff" stroke="#2b2230" stroke-width="4"/><path d="M98 244q10 6 20 0M96 252q12 6 24 0" stroke="#2b2230" stroke-width="2.5" fill="none"/><text class="pt-fl" x="250" y="178" font-size="22" fill="#ffd36e">★</text><text class="pt-fl d2" x="138" y="170" font-size="18" fill="#ff8fb8">★</text>';
 case 'bath':return '<path d="M136 240h128q0 46-64 46q-64 0-64-46z" fill="#8fd0ff" stroke="#2b2230" stroke-width="4" stroke-linejoin="round"/><path d="M136 240h128" stroke="#2b2230" stroke-width="4"/><g fill="#fff" stroke="#bfe0f5" stroke-width="2"><circle cx="184" cy="180" r="11"/><circle cx="204" cy="172" r="13"/><circle cx="222" cy="182" r="10"/><circle cx="198" cy="190" r="9"/></g><g fill="none" stroke="#fff" stroke-width="3"><circle class="pt-fl" cx="130" cy="210" r="8"/><circle class="pt-fl d2" cx="276" cy="200" r="10"/><circle class="pt-fl d3" cx="250" cy="150" r="6"/></g>';
 default:return '<text class="pt-fl" x="150" y="160" font-size="26" fill="#ff6f9c">♥</text><text class="pt-fl d2" x="236" y="150" font-size="32" fill="#ff8fb8">♥</text><text class="pt-fl d3" x="196" y="128" font-size="20" fill="#ffb0cf">♥</text>'}}
function sceneSvg(){const d=DIM[pet.type],w=d[0],h=d[1],closed=(pet.act==='sleep'||pet.act==='cuddle'||pet.act==='bath')?' pt-closed':'';
 return `<svg class="pt-art pt-${pet.act}${closed}" viewBox="0 0 400 300" preserveAspectRatio="xMidYMax slice" aria-hidden="true">${place().deco}${pre()}<g class="pt-pet"><ellipse cx="200" cy="242" rx="46" ry="26" fill="${d[3]}" stroke="#2b2230" stroke-width="4"/><svg x="${200-w/2}" y="${262-h}" width="${w}" height="${h}" viewBox="${d[2]}">${PS[pet.type]}</svg></g>${post()}</svg>`}

const base='<circle cx="150" cy="148" r="17" fill="#fff"/><path d="M122 250V206Q122 178 150 178Q178 178 178 206V250Z" fill="#fff"/>';
const baseW='<circle cx="150" cy="148" r="17" fill="#fff"/><path d="M124 236V206Q124 178 150 178Q176 178 176 206V236Z" fill="#fff"/>';
const P='#ffe3a3';
let stripes='';for(let i=0;i<6;i++)stripes+=`<path d="M${i*50} 0h50v58q-25 16-50 0z" fill="${i%2?'#e7eee4':'#4f7a5c'}"/>`;
const S=[
{id:'coffee',name:'Кофе ішіп жатыр',short:'Кофе',c:'#7aa383',bg:['#6c8f73','#3e5b4a'],say:'Mmm, дәмді-дәмді!',
 deco:stripes+'<rect x="18" y="92" width="72" height="120" rx="8" fill="#ffffff22"/><rect x="210" y="92" width="72" height="120" rx="8" fill="#ffffff22"/><rect x="104" y="112" width="92" height="6" rx="3" fill="#b98a5e"/><rect x="116" y="88" width="12" height="24" rx="3" fill="#d9b58a"/><rect x="132" y="94" width="12" height="18" rx="3" fill="#e8a5b3"/><rect y="258" width="300" height="12" fill="#b98a5e"/><rect y="270" width="300" height="90" fill="#2f4538"/>',
 fig:base+`<path d="M136 198h28v16q0 12-14 12q-14 0-14-12z" fill="${P}"/><path d="M164 202q11 0 11 8q0 8-11 8" fill="none" stroke="${P}" stroke-width="4"/><path d="M143 190q-5-7 0-12M151 190q-5-7 0-12M159 190q-5-7 0-12" stroke="#ffffffb0" stroke-width="3" fill="none" stroke-linecap="round"/>`},
{id:'sleep',name:'Ұйықтап жатыр',short:'Ұйқы',c:'#7c6fd0',bg:['#2c2f72','#5b4fa8'],say:'Zzz… тәтті түс көріп жатырмын',vb:'56 180 200 90',
 deco:'<path d="M236 42a30 30 0 1 0 22 52a24 24 0 1 1-22-52z" fill="#ffe9a8"/><g fill="#fff"><circle cx="50" cy="60" r="2.5"/><circle cx="110" cy="100" r="2"/><circle cx="170" cy="50" r="3"/><circle cx="70" cy="140" r="2"/><circle cx="260" cy="150" r="2.5"/><circle cx="200" cy="120" r="2"/></g><rect x="24" y="250" width="252" height="70" rx="18" fill="#8d7fd6"/><rect x="24" y="238" width="252" height="26" rx="12" fill="#cbbcf5"/>',
 fig:'<rect x="70" y="204" width="180" height="40" rx="20" fill="#fff"/><circle cx="92" cy="212" r="21" fill="#fff"/><path d="M122 206h128a14 14 0 0 1 14 14v26H122z" fill="#ffb3d1"/><text x="150" y="168" font-size="30" font-weight="800" fill="#fff" opacity=".9">z</text><text x="176" y="146" font-size="22" font-weight="800" fill="#fff" opacity=".7">z</text>'},
{id:'study',name:'Оқып жатыр',short:'Оқу',c:'#e59a63',bg:['#f3c88c','#e59a63'],say:'Тағы бір бет қалды…',
 deco:'<rect y="262" width="300" height="98" fill="#a86a43"/><rect x="30" y="248" width="70" height="14" rx="3" fill="#e0575f"/><rect x="36" y="234" width="62" height="14" rx="3" fill="#5ba3e0"/><rect x="32" y="220" width="66" height="14" rx="3" fill="#6fcf97"/><path d="M262 262v-84l-24 20" stroke="#5a3a28" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M228 190l44-12l6 22z" fill="#ffd36e"/><path d="M250 202L300 262H220z" fill="#fff3b0" opacity=".28"/>',
 fig:base+`<path d="M116 226q34-14 34 0q0-14 34 0v28q-34-14-34 0q0-14-34 0z" fill="${P}"/><path d="M150 226v28" stroke="#e59a63" stroke-width="2.5"/>`},
{id:'eat',name:'Тамақ ішіп жатыр',short:'Тамақ',c:'#ff8f86',bg:['#ffb199','#ff7e8a'],say:'Қандай дәмді!',
 deco:'<rect y="268" width="300" height="92" fill="#c25b63"/><ellipse cx="150" cy="268" rx="130" ry="10" fill="#e07680"/><g fill="#fff" opacity=".5"><circle cx="50" cy="80" r="4"/><circle cx="246" cy="110" r="3"/><circle cx="220" cy="50" r="5"/><circle cx="80" cy="150" r="3"/></g>',
 fig:base+`<path d="M116 212h68q0 32-34 32q-34 0-34-32z" fill="${P}"/><path d="M186 176l-24 28" stroke="#ffffffe0" stroke-width="5" stroke-linecap="round"/>`},
{id:'walk',name:'Серуендеп жатыр',short:'Серуен',c:'#5fb878',bg:['#8fd8f0','#c8f0b4'],say:'Таза ауа — керемет!',
 deco:'<circle cx="240" cy="70" r="28" fill="#fff3b0"/><ellipse cx="70" cy="86" rx="36" ry="12" fill="#fff" opacity=".85"/><path d="M0 250Q80 200 160 245T300 230V360H0z" fill="#7fcf8a"/><path d="M0 292Q100 262 300 288V360H0z" fill="#5fb878"/><rect x="40" y="208" width="8" height="38" fill="#8a5a3c"/><circle cx="44" cy="198" r="23" fill="#46a35e"/><rect x="252" y="214" width="8" height="34" fill="#8a5a3c"/><circle cx="256" cy="204" r="20" fill="#46a35e"/>',
 fig:baseW+'<path d="M138 232l-12 42M162 232l14 40M124 198l-14 26M176 198l14 20" stroke="#fff" stroke-width="11" stroke-linecap="round" fill="none"/>'},
{id:'music',name:'Музыка тыңдап жатыр',short:'Музыка',c:'#b062d8',bg:['#8a5be0','#e66fb8'],say:'Бұл менің сүйікті әнім!',
 deco:'<g fill="#ffffff30"><rect x="20" y="290" width="24" height="50" rx="8"/><rect x="56" y="270" width="24" height="70" rx="8"/><rect x="92" y="298" width="24" height="42" rx="8"/><rect x="184" y="282" width="24" height="58" rx="8"/><rect x="220" y="262" width="24" height="78" rx="8"/><rect x="256" y="296" width="24" height="44" rx="8"/></g><g fill="#fff" opacity=".8" font-weight="800"><text x="48" y="120" font-size="34">♪</text><text x="230" y="150" font-size="40">♫</text><text x="206" y="82" font-size="26">♪</text></g>',
 fig:base+`<path d="M129 150a21 21 0 0 1 42 0" fill="none" stroke="${P}" stroke-width="6" stroke-linecap="round"/><rect x="124" y="147" width="10" height="20" rx="5" fill="${P}"/><rect x="166" y="147" width="10" height="20" rx="5" fill="${P}"/>`},
{id:'sport',name:'Жаттығып жатыр',short:'Спорт',c:'#ff9a5a',bg:['#ffa05c','#ffd57a'],say:'Күш-қуат толы!',vb:'86 100 128 150',
 deco:'<circle cx="150" cy="300" r="100" fill="#ffffff30"/><rect y="300" width="300" height="60" fill="#d97a3f"/>',
 fig:baseW+`<path d="M126 200L108 132M174 200L192 132" stroke="#fff" stroke-width="10" stroke-linecap="round"/><rect x="92" y="124" width="116" height="8" rx="4" fill="${P}"/><rect x="86" y="108" width="12" height="40" rx="5" fill="${P}"/><rect x="100" y="114" width="10" height="28" rx="4" fill="${P}"/><rect x="202" y="108" width="12" height="40" rx="5" fill="${P}"/><rect x="190" y="114" width="10" height="28" rx="4" fill="${P}"/>`},
{id:'game',name:'Ойын ойнап жатыр',short:'Ойын',c:'#6a5bd6',bg:['#1f2866','#4b2a9a'],say:'Тағы бір раунд!',
 deco:'<g fill="#7de3ff" opacity=".55"><rect x="30" y="70" width="14" height="14"/><rect x="236" y="96" width="18" height="18"/><rect x="64" y="200" width="10" height="10"/><rect x="250" y="220" width="12" height="12"/></g><g fill="#ff7fd1" opacity=".55"><rect x="200" y="50" width="12" height="12"/><rect x="40" y="130" width="16" height="16"/><rect x="262" y="160" width="10" height="10"/></g><rect y="290" width="300" height="70" fill="#2a1d6e"/>',
 fig:base+`<path d="M124 208l14 10M176 208l-14 10" stroke="#fff" stroke-width="9" stroke-linecap="round"/><rect x="116" y="204" width="68" height="32" rx="15" fill="${P}"/><path d="M130 214v14M123 221h14" stroke="#4b2a9a" stroke-width="4" stroke-linecap="round"/><circle cx="165" cy="217" r="3.6" fill="#4b2a9a"/><circle cx="174" cy="226" r="3.6" fill="#4b2a9a"/>`}
];
const CUSTOM={id:'custom',name:'Өз статусым',short:'Өз статусым',c:'#c58be0',bg:['#ffc2dc','#c4b4f7'],say:'Менің өз күйім ✨',
 deco:'<g fill="#fff" opacity=".55"><circle cx="48" cy="80" r="5"/><circle cx="250" cy="110" r="4"/><circle cx="220" cy="60" r="6"/><circle cx="70" cy="180" r="4"/></g><path d="M0 300Q150 250 300 300V360H0z" fill="#ffffff40"/>',
 fig:base+`<path d="M150 70l7 15 16 2-12 11 3 16-14-8-14 8 3-16-12-11 16-2z" fill="${P}"/>`};
const byId=id=>id==='custom'?CUSTOM:S.find(x=>x.id===id);
const icon=s=>`<svg viewBox="${s.vb||'98 118 104 138'}" aria-hidden="true">${s.fig}</svg>`;
const art=s=>`<svg class="st-art" viewBox="0 0 300 360" preserveAspectRatio="xMidYMid meet" aria-hidden="true"><defs><linearGradient id="stg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${s.bg[0]}"/><stop offset="1" stop-color="${s.bg[1]}"/></linearGradient></defs><rect width="300" height="360" fill="url(#stg)"/>${s.deco}${s.id==='sleep'?'':'<ellipse cx="150" cy="292" rx="54" ry="9" fill="#0000002e"/>'}<g class="st-fig">${s.fig}</g></svg>`;

const $=id=>document.getElementById(id);
const esc=t=>String(t).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const MS=864e5,MON=Array.from({length:12},(_,i)=>T('mon.'+i));
/* ---- Тіл: мәтіндерді таңдалған тілге аудару ---- */
PLACES.forEach(p=>{p.name=T('place.'+p.id)});
Object.keys(ACT).forEach(k=>{ACT[k].n=T('act.'+k+'.n');ACT[k].v=T('act.'+k+'.v')});
Object.keys(PN).forEach(k=>{PN[k]=T('pet.'+k)});
Object.keys(SAY).forEach(t=>Object.keys(SAY[t]).forEach(a=>{SAY[t][a]=T('say.'+t+'.'+a)}));
S.concat([CUSTOM]).forEach(x=>{x.name=T('s.'+x.id+'.name');x.short=T('s.'+x.id+'.short');x.say=T('s.'+x.id+'.say')});

/* ---- Күй: бәрі осы қолданушының өз жазбасы (дерекқордан келеді) ---- */
const Y=window.YEN_STATE||{};
let st=Y.st||null,hist=Array.isArray(Y.hist)?Y.hist:[],bday=Y.bday||null;
const GOAL=8,MAXW=20,pad2=n=>String(n).padStart(2,'0');
const today=()=>{const d=new Date();return d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate())};
let water=(Y.water&&Y.water.d===today())?{d:Y.water.d,n:Math.min(MAXW,+Y.water.n||0)}:{d:today(),n:0};
let pet=Object.assign({type:'cat',place:'home',act:'cuddle',start:Date.now()},Y.pet||{});
if(!PS[pet.type])pet.type='cat';
/* ---- Геймификация: көрсеткіштер, XP, деңгей, тиын ---- */
const clamp=(v,a=0,b=100)=>Math.max(a,Math.min(b,v));
['h','f','e','c'].forEach(k=>{pet[k]=Number.isFinite(+pet[k])&&pet[k]!==undefined&&pet[k]!==null?clamp(+pet[k]):80});
pet.xp=Math.max(0,+pet.xp||0);pet.coins=(pet.coins==null||isNaN(+pet.coins))?5:Math.max(0,+pet.coins);pet.tk=+pet.tk||Date.now();
const GST=[['h','💗','g.happy','#ff7fb0'],['f','🍙','g.full','#ffb15c'],['e','⚡','g.energy','#6fa8f5'],['c','✨','g.clean','#4fcdb0']];
const AI={feed:'🍙',sleep:'💤',play:'🎾',bath:'🛁',cuddle:'🤍'};
// p — негізгі көрсеткіш; fx — шашылатын эмодзи
const GA={feed:{p:'f',f:28,h:3,c:-5,xp:6,coin:1,fx:'🍙'},play:{p:'h',h:22,e:-16,f:-8,c:-4,xp:8,coin:2,fx:'🎾'},cuddle:{p:'h',h:12,xp:3,coin:1,fx:'💗'},sleep:{p:'e',e:35,f:-4,xp:4,coin:1,fx:'💤'},bath:{p:'c',c:40,h:-2,xp:5,coin:1,fx:'🫧'}};
const TREAT=5;
function lvl(xp){let L=1,need=60,x=xp;while(x>=need){x-=need;L++;need=40+20*L}return{L,cur:Math.floor(x),need}}
const stageName=L=>T('g.st'+(L<3?0:L<6?1:L<10?2:3));
// Уақыт өткен сайын көрсеткіштер баяу төмендейді (кемі 6 сағатқа дейін ғана есептеледі)
function gameTick(){
 const now=Date.now(),mins=Math.max(0,Math.min(360,(now-pet.tk)/60000));
 if(mins>0){
  pet.f=Math.max(5,pet.f-mins*.15);pet.c=Math.max(5,pet.c-mins*.10);
  pet.e=pet.act==='sleep'?Math.min(100,pet.e+mins*.4):Math.max(5,pet.e-mins*.08);
  let hd=.07;if(pet.f<25)hd+=.08;if(pet.c<25)hd+=.05;if(pet.e<20)hd+=.05;
  pet.h=Math.max(5,pet.h-mins*hd);
 }
 pet.tk=now;
}
gameTick();
let flash=null,flashT=0;
function needMsg(){let lo=null;GST.forEach(([k])=>{if(pet[k]<25&&(lo===null||pet[k]<pet[lo]))lo=k});return lo?T('g.need_'+({h:'happy',f:'full',e:'energy',c:'clean'})[lo]):null}
const bubbleText=()=>flash||needMsg()||SAY[pet.type][pet.act]||T('g.ok');
function flashSay(txt,ms=5000){flash=txt;clearTimeout(flashT);flashT=setTimeout(()=>{flash=null;updateGame()},ms);updateGame()}
function updateGame(){
 const L=lvl(pet.xp);
 GST.forEach(([k])=>{const w=$('gs_'+k);if(!w)return;w.classList.toggle('low',pet[k]<25);w.querySelector('i').style.width=pet[k]+'%';w.querySelector('b').textContent=Math.round(pet[k])});
 const set=(id,v)=>{const e=$(id);if(e)e.textContent=v};
 set('gmLv',T('g.lv')+' '+L.L+' · '+stageName(L.L));set('gmCoins','🪙 '+pet.coins);set('gmXpt',T('g.xp',L.cur,L.need));
 const xb=$('gmXp');if(xb)xb.style.width=Math.round(L.cur/L.need*100)+'%';
 set('ptSay',bubbleText());
 set('gmOpenInfo',T('g.lv')+' '+L.L+' · 🪙 '+pet.coins);const tb=document.querySelector('.gmw-act.treat');if(tb)tb.classList.toggle('off',pet.coins<TREAT);
}
const sceneEl=()=>document.querySelector('#gmModal .sx-scene');
function burst(emoji,n=6){const sc=sceneEl();if(!sc)return;for(let i=0;i<n;i++){const f=document.createElement('span');f.className='gm-fx';f.textContent=emoji;f.style.left=(36+Math.random()*28)+'%';f.style.setProperty('--dx',(Math.random()*80-40)+'px');f.style.animationDelay=(i*90)+'ms';sc.append(f);setTimeout(()=>f.remove(),1700)}}
function floatText(cls,txt,ms){const sc=sceneEl();if(!sc)return;const f=document.createElement('div');f.className=cls;f.textContent=txt;sc.append(f);setTimeout(()=>f.remove(),ms)}
function renderGameScene(animate){
 const w=$('gmScene');if(!w)return;
 w.className='sx-scene pt-card gm-scene'+(animate?' in':'')+(pet.act==='sleep'?' is-night':'');w.style.setProperty('--c',place().c);
 w.innerHTML=sceneSvg()+`<div class="st-bubble"><span id="ptSay">${esc(bubbleText())}</span><i></i><i></i></div>`;
}
function onGameKey(e){if(e.key==='Escape')closeGame()}
function openGame(){
 if($('gmModal'))return;gameTick();
 const m=document.createElement('div');m.id='gmModal';m.className='gmw-back';
 m.innerHTML=`<div class="gmw" role="dialog" aria-modal="true" aria-label="${esc(T('g.title'))}">
  <div class="gmw-bar"><div class="gmw-dots"><i></i><i></i><i></i></div><b>🐾 ${esc(T('g.title'))}</b><button type="button" class="gmw-x" id="gmClose" aria-label="${esc(T('g.close'))}">×</button></div>
  <div class="gmw-body"><aside class="gmw-side">${gameHtml()}</aside>
  <div class="gmw-main"><div id="gmScene"></div>
   <div class="gmw-acts">${Object.keys(ACT).map(k=>`<button type="button" class="gmw-act" data-a="${k}"><span class="e">${AI[k]}</span><b>${esc(ACT[k].n)}</b></button>`).join('')}<button type="button" class="gmw-act treat ${pet.coins<TREAT?'off':''}" data-a="treat"><span class="e">🍬</span><b>${esc(T('g.treat'))}</b><small>${esc(T('g.treat_cost',TREAT))}</small></button></div>
  </div></div></div>`;
 document.body.append(m);document.body.style.overflow='hidden';
 m.addEventListener('click',e=>{if(e.target===m)closeGame()});
 $('gmClose').onclick=closeGame;
 m.querySelectorAll('.gmw-act').forEach(b=>b.onclick=()=>{b.dataset.a==='treat'?doTreat():doAct(b.dataset.a)});
 document.addEventListener('keydown',onGameKey);
 renderGameScene(true);updateGame();$('gmClose').focus();
}
function closeGame(){
 const m=$('gmModal');if(!m)return;m.remove();document.body.style.overflow='';document.removeEventListener('keydown',onGameKey);
 renderPet(false);renderRing();
}
function doAct(v){
 gameTick();const A=GA[v];
 if(v==='play'&&pet.e<15){flashSay(T('g.tired'));return}
 const prev=pet.act,Lb=lvl(pet.xp).L,useful=pet[A.p]<96;
 pet.act=v;pet.start=Date.now();
 if(useful){['h','f','e','c'].forEach(k=>{if(A[k])pet[k]=clamp(pet[k]+A[k])});pet.xp+=A.xp;pet.coins+=A.coin}
 const La=lvl(pet.xp).L;if(La>Lb)pet.coins+=5;
 flash=useful?SAY[pet.type][v]:T('g.noneed');clearTimeout(flashT);flashT=setTimeout(()=>{flash=null;updateGame()},5000);
 persist();
 renderPet(false);if(prev!==v)renderGameScene(true);updateGame();
 renderRing();
 if(useful){burst(A.fx);floatText('gm-gain',T('g.gain',A.xp,A.coin),1500)}
 if(La>Lb){floatText('gm-up',T('g.up',La),2800);burst('✨',9)}
}
function doTreat(){
 gameTick();
 if(pet.coins<TREAT){flashSay(T('g.broke'));return}
 const Lb=lvl(pet.xp).L;
 pet.coins-=TREAT;pet.h=clamp(pet.h+15);pet.f=clamp(pet.f+10);pet.xp+=10;
 const La=lvl(pet.xp).L;if(La>Lb)pet.coins+=5;
 flash=T('g.treat_say');clearTimeout(flashT);flashT=setTimeout(()=>{flash=null;updateGame()},5000);
 persist();updateGame();burst('🍬');floatText('gm-gain',T('g.gain',10,-TREAT),1500);
 if(La>Lb){floatText('gm-up',T('g.up',La),2800);burst('✨',9)}
}
function gameHtml(){
 const L=lvl(pet.xp);
 return `<div class="gm"><div class="gm-top"><span class="gm-lv" id="gmLv">${esc(T('g.lv'))} ${L.L} · ${esc(stageName(L.L))}</span><span class="gm-coins" id="gmCoins">🪙 ${pet.coins}</span></div>
 <div class="gm-xp"><i id="gmXp" style="width:${Math.round(L.cur/L.need*100)}%"></i></div><small class="gm-xpt" id="gmXpt">${esc(T('g.xp',L.cur,L.need))}</small>
 <div class="gm-stats">${GST.map(([k,ic,lb,col])=>`<div class="gm-s ${pet[k]<25?'low':''}" id="gs_${k}"><span>${ic} ${esc(T(lb))}</span><div class="gm-bar"><i style="width:${pet[k]}%;background:${col}"></i></div><b>${Math.round(pet[k])}</b></div>`).join('')}</div>
 <p class="gm-tip">${esc(T('g.tip'))}</p></div>`;
}
let pending=null;
function send(){if(!pending)return;pending=null;fetch('status_api.php',{method:'POST',keepalive:true,credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':window.YEN_CSRF||''},body:JSON.stringify({st,hist,pet,bday,water})}).catch(()=>{})}
function persist(){clearTimeout(pending);pending=setTimeout(()=>{pending=1;send()},250)}
addEventListener('pagehide',()=>{if(pending){clearTimeout(pending);pending=1;send()}});

/* ---- Көмекші ---- */
const place=()=>PLACES.find(p=>p.id===pet.place)||PLACES[0];
function ago(t){const m=Math.max(0,Math.floor((Date.now()-t)/60000));if(m<1)return T('ago.now');if(m<60)return m+' '+T('ago.min');return Math.floor(m/60)+' '+T('ago.h')+' '+(m%60)+' '+T('ago.min')}
const label=()=>{const s=byId(st.id);return st.id==='custom'&&st.text?st.text:s.name};
const petFace=(t,s)=>{const d=DIM[t];return `<svg viewBox="${d[2]}" width="${s}" height="${s}" aria-hidden="true">${PS[t]}</svg>`};
const IC_USER='<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><circle cx="12" cy="7.5" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7z"/></svg>';
const IC_PAW='<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><ellipse cx="5.5" cy="10" rx="2.2" ry="2.8"/><ellipse cx="10" cy="5.8" rx="2.2" ry="2.8"/><ellipse cx="14.5" cy="5.8" rx="2.2" ry="2.8"/><ellipse cx="19" cy="10" rx="2.2" ry="2.8"/><path d="M12 11c-3.3 0-6 3.1-6 5.6 0 1.7 1.3 2.6 2.8 2.6 1.1 0 2-.5 3.2-.5s2.1.5 3.2.5c1.5 0 2.8-.9 2.8-2.600C18 14.1 15.3 11 12 11z"/></svg>';
const IC_EDIT='<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.500a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>';

/* ---- Сағат ---- */
function clock(){const d=new Date();$('sxClock').textContent=String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')}

/* ---- Туған күн (қолданушының өз деректері) ---- */
const day0=d=>new Date(d.getFullYear(),d.getMonth(),d.getDate());
const nextOf=(m,d,t)=>{let x=new Date(t.getFullYear(),m-1,d);if(x<t)x=new Date(t.getFullYear()+1,m-1,d);return x};
const lab=x=>x.getDate()+' '+MON[x.getMonth()]+' '+x.getFullYear();
function bdayHtml(t){
 const head='<span class="cd-deco" aria-hidden="true">✿ ♡ ✧</span><div class="cd-label">'+esc(T('bd.label'))+'</div>';
 if(!bday)return head+'<div class="cd-ask">'+esc(T('bd.ask'))+'</div><form class="cd-inline" id="holBdForm"><input type="date" id="holBdInput" required><button class="btn primary" type="submit">'+esc(T('bd.save'))+'</button></form>';
 const [by,bm,bd]=bday.split('-').map(Number),nx=nextOf(bm,bd,t),n=Math.round((nx-t)/MS),age=nx.getFullYear()-by;
 const big=n===0?'<b>🎉</b><span>'+esc(T('bd.today'))+'</span>':'<b>'+n+'</b><span>'+esc(T('bd.left'))+'</span>';
 return head+'<div class="cd-num">'+big+'</div><div class="cd-sub">'+(n===0?esc(T('bd.wish')):(age>0?esc(T('bd.age',age)):'')+esc(lab(nx)))+'</div><button type="button" class="cd-link" id="holBdEdit">'+esc(T('bd.edit'))+'</button>';
}
function renderBday(){
 $('holBd').innerHTML=bdayHtml(day0(new Date()));
 const f=$('holBdForm');if(f)f.onsubmit=e=>{e.preventDefault();const v=$('holBdInput').value;if(!v)return;bday=v;persist();renderBday()};
 const b=$('holBdEdit');if(b)b.onclick=()=>{const v=bday||'';bday=null;persist();renderBday();$('holBdInput').value=v;$('holBdInput').focus()};
}

/* ---- Сол жақ карта: менің статусым ---- */
const me=$('sxMe');
let menuOpen=false,picking=!(st&&byId(st.id));
function renderMe(anim){
 if(picking||!st||!byId(st.id)){
  picking=true;
  const own=hist.length?'':'';
  me.className='sx-card sx-me is-pick';
  me.innerHTML=`<div class="sx-head"><span class="sx-ico">${IC_USER}</span><b>${esc(T('me.q'))}</b>${st&&byId(st.id)?`<button type="button" class="sx-ghost" id="sxCancel">${esc(T('me.cancel'))}</button>`:''}</div>
  <div class="sx-pick"><div class="st-grid" id="stGrid">${S.map(s=>`<button type="button" class="st-tile" data-id="${s.id}" style="--c:${s.c}"><span class="st-ico">${icon(s)}</span><b>${s.short}</b></button>`).join('')}<button type="button" class="st-tile st-own" id="stOwn"><span class="st-ico plus">＋</span><b>${esc(T('me.own'))}</b></button></div>
  <form class="st-custom" id="stCustom" autocomplete="off" hidden><input id="stCustomText" maxlength="28" placeholder="${esc(T('me.ph'))}" aria-label="${esc(T('me.own_aria'))}"><button class="btn primary" type="submit">${esc(T('me.set'))}</button></form></div>
  <div class="sx-hint"><span aria-hidden="true">✨</span><p>${T('me.hint')}</p></div>`;
  me.querySelectorAll('.st-tile[data-id]').forEach(b=>b.onclick=()=>choose(b.dataset.id));
  const cf=$('stCustom'),ct=$('stCustomText');
  $('stOwn').onclick=()=>{cf.hidden=false;ct.focus()};
  cf.onsubmit=e=>{e.preventDefault();const t=ct.value.trim();if(t){ct.value='';choose('custom',t)}};
  const c=$('sxCancel');if(c)c.onclick=()=>{picking=false;renderMe()};
  return;
 }
 const s=byId(st.id),others=hist.filter(h=>h.id!==st.id||h.text!==st.text).slice(0,3);
 me.className='sx-card sx-me';
 me.innerHTML=`<div class="sx-art ${anim?'in':''}" style="--c:${s.c};--b0:${s.bg[0]};--b1:${s.bg[1]}">${art(s)}</div>
 <div class="sx-head on-art"><span class="sx-ico">${IC_USER}</span><b>${esc(T('me.title'))} – <span id="stAgo">${ago(st.start)}</span></b>
  <span class="sx-head-r">${others.map((h,i)=>{const o=byId(h.id);return `<button type="button" class="st-badge" data-i="${i}" style="--c:${o.c}" title="${esc((h.id==='custom'&&h.text)||o.name)}" aria-label="${esc((h.id==='custom'&&h.text)||o.name)}">${icon(o)}</button>`}).join('')}
  <button type="button" class="sx-dots" id="sxDots" aria-label="${esc(T('me.menu'))}" aria-haspopup="true" aria-expanded="${menuOpen}">⋮</button></span>
  <div class="sx-menu" id="sxMenu" ${menuOpen?'':'hidden'}><button type="button" id="stChange">${esc(T('me.change'))}</button><button type="button" id="stStop">${esc(T('me.stop'))}</button></div></div>
 <div class="st-bubble"><span>${esc(st.id==='custom'&&st.text?st.text:s.say)}</span><i></i><i></i></div>
 <div class="sx-foot"><div class="sx-now"><span class="sx-play">${icon(s)}</span><b>${esc(label())}</b></div><button type="button" class="sx-more" id="sxMore">${IC_EDIT}<span>${esc(T('me.edit'))}</span></button></div>`;
 $('sxDots').onclick=e=>{e.stopPropagation();menuOpen=!menuOpen;$('sxMenu').hidden=!menuOpen;e.currentTarget.setAttribute('aria-expanded',menuOpen)};
 $('sxMore').onclick=$('stChange').onclick=()=>{menuOpen=false;picking=true;renderMe()};
 $('stStop').onclick=()=>{menuOpen=false;st=null;persist();picking=true;renderMe()};
 me.querySelectorAll('.st-badge').forEach(b=>b.onclick=()=>choose(others[+b.dataset.i].id,others[+b.dataset.i].text));
}
addEventListener('click',()=>{if(menuOpen){menuOpen=false;const m=$('sxMenu');if(m)m.hidden=true}});
function choose(id,text){
 if(st&&(st.id!==id||(st.text||'')!==(text||''))){hist=[{id:st.id,text:st.text,start:st.start},...hist.filter(h=>!(h.id===st.id&&h.text===st.text))].slice(0,6)}
 hist=hist.filter(h=>!(h.id===id&&(h.text||'')===(text||'')));
 st={id,start:Date.now()};if(text)st.text=text;
 picking=false;persist();renderMe(true);
}

/* ---- Оң жақ карта: жануардың күйі ---- */
const pc=$('sxPet');
function renderPet(animate){
 const a=ACT[pet.act],pl=place(),sleepy=pet.act==='sleep';
 pc.style.setProperty('--c',pl.c);
 pc.className='sx-card sx-pet'+(sleepy?' is-night':'');
 const PAW=IC_PAW.replace('width="20" height="20"','width="14" height="14"');
 pc.innerHTML=`<div class="sx-scene pt-card ${animate?'in':''}">${sceneSvg()}
  <div class="sx-head on-art"><span class="sx-ico">${IC_PAW}</span><b>${esc(T('pet.title'))} – <span id="ptAgo">${ago(pet.start)}</span></b></div>
  <div class="st-bubble"><span>${esc(SAY[pet.type][pet.act])}</span><i></i><i></i></div></div>
 <div class="sx-panel"><div class="sx-who"><b>${esc(PN[pet.type])} ${a.v}</b><small>${esc(pl.name)}</small></div>
  <button type="button" class="gm-open" id="gmOpen"><span>🎮 ${esc(T('g.open'))}</span><small id="gmOpenInfo">${esc(T('g.lv'))} ${lvl(pet.xp).L} · 🪙 ${pet.coins}</small></button>
  <h3>${PAW} ${esc(T('pet.animal'))}</h3><div class="pt-chips">${Object.keys(PS).map(t=>`<button type="button" class="pt-chip ${pet.type===t?'on':''}" data-k="type" data-v="${t}">${petFace(t,30)}<span>${PN[t]}</span></button>`).join('')}</div>
  <h3>${PAW} ${esc(T('pet.where'))}</h3><div class="pt-chips">${PLACES.map(p=>`<button type="button" class="pt-chip ${pet.place===p.id?'on':''}" data-k="place" data-v="${p.id}"><i class="dot" style="background:${p.c}"></i><span>${p.name}</span></button>`).join('')}</div>
  <h3>${PAW} ${esc(T('pet.do'))}</h3><div class="pt-chips">${Object.keys(ACT).map(k=>`<button type="button" class="pt-chip ${pet.act===k?'on':''}" data-k="act" data-v="${k}"><span>${ACT[k].n}</span></button>`).join('')}</div></div>`;
 $('gmOpen').onclick=openGame;
 pc.querySelectorAll('.pt-chip').forEach(b=>b.onclick=()=>{const k=b.dataset.k,v=b.dataset.v;if(pet[k]===v)return;pet[k]=v;if(k==='act'||k==='type')pet.start=Date.now();persist();renderPet(true);renderRing()});
}

setInterval(()=>{gameTick();updateGame();const a=$('stAgo');if(a&&st)a.textContent=ago(st.start);const p=$('ptAgo');if(p)p.textContent=ago(pet.start);clock();renderRing();renderBdayIfNewDay();waterNewDay()},20000);
let lastDay=new Date().getDate();function renderBdayIfNewDay(){const d=new Date().getDate();if(d!==lastDay){lastDay=d;renderBday()}}
/* ---- Виджеттер: күн сақинасы және су ішу ---- */
function renderRing(){
 const n=new Date(),d0=new Date(n.getFullYear(),n.getMonth(),n.getDate()),f=(n-d0)/MS,h=n.getHours();
 const part=T(h<5?'ring.night':h<12?'ring.morning':h<18?'ring.day':'ring.evening'),C=2*Math.PI*46;
 $('sxRing').innerHTML=`<div class="rg"><svg viewBox="0 0 110 110" width="112" height="112" aria-hidden="true"><circle cx="55" cy="55" r="46" fill="none" stroke="#eee8f3" stroke-width="9"/><circle cx="55" cy="55" r="46" fill="none" stroke="url(#rgG)" stroke-width="9" stroke-linecap="round" stroke-dasharray="${(C*f).toFixed(1)} ${C.toFixed(1)}" transform="rotate(-90 55 55)"/><defs><linearGradient id="rgG"><stop offset="0" stop-color="#d77ba5"/><stop offset="1" stop-color="#9c71b5"/></linearGradient></defs></svg><span class="rg-face">${petFace(pet.type,56)}</span></div><b>${esc(part)}</b><small>${esc(T('ring.sub',h,pad2(n.getMinutes()),Math.round(f*100)))}</small>`;
}
function glassSvg(n){
 const f=Math.min(1,n/GOAL),top=84-62*f,h=62*f+8;
 const mouth=n===0?'<path d="M33 66q7-6 14 0" fill="none" stroke="#2b2230" stroke-width="3" stroke-linecap="round"/>'
  :n>=GOAL?'<path d="M32 60q8 11 16 0z" fill="#2b2230" stroke="#2b2230" stroke-width="2.5" stroke-linejoin="round"/><path d="M35 64q5 4 10 0" fill="#f08aa0"/>'
  :'<path d="M34 61q6 6 12 0" fill="none" stroke="#2b2230" stroke-width="3" stroke-linecap="round"/>';
 const eyes=n>=GOAL?'<path d="M26 50q4-6 8 0M46 50q4-6 8 0" fill="none" stroke="#2b2230" stroke-width="3" stroke-linecap="round"/>'
  :'<ellipse cx="30" cy="50" rx="3.4" ry="4.6" fill="#2b2230"/><ellipse cx="50" cy="50" rx="3.4" ry="4.6" fill="#2b2230"/><circle cx="31.2" cy="48.4" r="1.2" fill="#fff"/><circle cx="51.2" cy="48.4" r="1.2" fill="#fff"/>';
 const brows=n===0?'<path d="M24 41l9 3M56 41l-9 3" stroke="#2b2230" stroke-width="2.6" stroke-linecap="round"/>':'';
 return `<svg viewBox="0 0 80 100" width="78" height="98" aria-hidden="true"><defs><clipPath id="wgC"><path d="M14 22h52l-5 62a7 7 0 0 1-7 6H26a7 7 0 0 1-7-6z"/></clipPath><linearGradient id="wgW" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9ee0ff"/><stop offset="1" stop-color="#5aaef0"/></linearGradient></defs><path d="M50 24L58 6h12" fill="none" stroke="#ff6f8f" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/><path d="M14 22h52l-5 62a7 7 0 0 1-7 6H26a7 7 0 0 1-7-6z" fill="#ffffff40"/><g clip-path="url(#wgC)"><rect class="wt-level" x="8" y="${top.toFixed(1)}" width="64" height="${h.toFixed(1)}" fill="url(#wgW)" opacity=".95"/></g><path d="M14 22h52l-5 62a7 7 0 0 1-7 6H26a7 7 0 0 1-7-6z" fill="none" stroke="#fff" stroke-width="3.2" stroke-linejoin="round"/>${brows}${eyes}<ellipse cx="22" cy="60" rx="4.5" ry="3" fill="#f7a8b4" opacity=".85"/><ellipse cx="58" cy="60" rx="4.5" ry="3" fill="#f7a8b4" opacity=".85"/>${mouth}</svg>`;
}
function renderWater(pulse){
 const n=water.n,hint=n===0?T('w.h0'):n>=GOAL?T('w.hdone'):T('w.hmid',GOAL-n);
 $('sxWater').innerHTML=`<div class="wt" role="group" aria-label="${esc(T('w.title')+': '+T('w.count',n,GOAL))}"><div class="wt-glass ${pulse?'pop':''}">${glassSvg(n)}</div><div class="wt-info"><span class="wt-label">${esc(T('w.title'))}</span><div class="wt-count"><b>${n}</b><small>/ ${GOAL}</small></div><p class="wt-hint">${esc(hint)}</p><div class="wt-btns"><button type="button" class="wt-minus" id="wtMinus" aria-label="${esc(T('w.undo'))}" ${n<=0?'disabled':''}>−</button><button type="button" class="wt-plus" id="wtPlus" ${n>=MAXW?'disabled':''}>${esc(T('w.btn'))}</button></div></div></div>`;
 $('wtPlus').onclick=()=>{water.n=Math.min(MAXW,water.n+1);persist();renderWater(true)};
 $('wtMinus').onclick=()=>{water.n=Math.max(0,water.n-1);persist();renderWater(false)};
}
function waterNewDay(){const d=today();if(water.d!==d){water={d,n:0};persist();renderWater(false)}}

clock();renderBday();renderRing();renderWater(false);renderMe(false);renderPet(false);

})();
</script>
<?php require 'inc_footer.php'; ?>
