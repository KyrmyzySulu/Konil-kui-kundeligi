<?php
// Статусты сақтау: тек кірген қолданушының өз жолына жазады (user_id сессиядан алынады).
require_once 'auth.php'; require_once 'inc_status.php';
header('Content-Type: application/json; charset=utf-8');
if(!logged_in()){ http_response_code(401); exit('{"ok":false}'); }
if($_SERVER['REQUEST_METHOD']!=='POST'){ http_response_code(405); exit('{"ok":false}'); }
if(!hash_equals($_SESSION['csrf']??'', $_SERVER['HTTP_X_CSRF_TOKEN']??'')){ http_response_code(403); exit('{"ok":false}'); }
$raw=file_get_contents('php://input');
if(strlen($raw)>20000){ http_response_code(413); exit('{"ok":false}'); }
$in=json_decode($raw,true);
if(!is_array($in)){ http_response_code(400); exit('{"ok":false}'); }
try{ status_save((int)$_SESSION['user_id'],$in); echo '{"ok":true}'; }
catch(Throwable $x){ http_response_code(500); echo '{"ok":false}'; }
