USE mood_journal;
-- Кіру әрекеттерін шектеу кестесі (код өзі де жасай алады, бірақ қолмен іске қосқан дұрыс).
CREATE TABLE IF NOT EXISTS login_attempts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 ip VARCHAR(45) NOT NULL,
 email VARCHAR(190) NOT NULL,
 attempted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_ip_time (ip, attempted_at),
 INDEX idx_email_ip_time (email, ip, attempted_at)
);
