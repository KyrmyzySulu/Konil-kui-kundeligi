<?php
// Өз жазбаларыңды CSV файл ретінде жүктеу (тек кірген қолданушының деректері).
require_once 'auth.php'; require_login();
$q=db()->prepare('SELECT entry_date,mood,score,category,note FROM mood_entries WHERE user_id=? ORDER BY entry_date DESC,id DESC');
$q->execute([current_user()['id']]);
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="kundelik-'.date('Y-m-d').'.csv"');
$o=fopen('php://output','w'); fwrite($o,"\xEF\xBB\xBF");
fputcsv($o,explode('|',t('csv.h')));
$safe=function($v){ $v=(string)$v; return ($v!=='' && strpos("=+-@\t\r",$v[0])!==false) ? "'".$v : $v; };
while($r=$q->fetch()) fputcsv($o,[$r['entry_date'],$safe(mood_name($r['mood'])),$r['score'],$safe(cat_name($r['category']??'')),$safe($r['note'])]);
