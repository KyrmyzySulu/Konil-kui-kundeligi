<?php require_once 'auth.php';require_login();$uid=current_user()['id'];$q=db()->prepare('SELECT mood,COUNT(*) n FROM mood_entries WHERE user_id=? GROUP BY mood ORDER BY n DESC');$q->execute([$uid]);$dist=$q->fetchAll();$q=db()->prepare('SELECT DATE_FORMAT(entry_date,"%Y-%m") ym,ROUND(AVG(score),1) avgscore,COUNT(*) n FROM mood_entries WHERE user_id=? GROUP BY ym ORDER BY ym DESC LIMIT 6');$q->execute([$uid]);$months=array_reverse($q->fetchAll());$q=db()->prepare('SELECT COUNT(*) total, AVG(score) avgscore FROM mood_entries WHERE user_id=?');$q->execute([$uid]);$st=$q->fetch();
$moodInfo=array_map(fn($x)=>[$x['emoji'],$x['dash']],mood_registry());
$cq=db()->prepare('SELECT mood,note,entry_date FROM mood_entries WHERE user_id=? AND entry_date>=DATE_SUB(CURDATE(),INTERVAL 24 MONTH) ORDER BY entry_date,id');$cq->execute([$uid]);$cal=[];foreach($cq->fetchAll() as $r){$cal[$r['entry_date']][]=['m'=>$r['mood'],'n'=>mb_substr((string)$r['note'],0,160)];}
$ms=explode(',',t('mon.short'));
$monthLabels=array_map(fn($m)=>$ms[(int)substr($m['ym'],5,2)-1]??$m['ym'],$months);
$maxN=$dist?max(array_map('intval',array_column($dist,'n'))):1;$topMood=$dist[0]['mood']??null;
$total=(int)($st['total']??0);$avgTxt=$total>0?number_format((float)$st['avgscore'],1):'0';$title=t('nav.stats');require 'inc_header.php';?><div class="page-intro"><div class="eyebrow"><?=e(t('ins.eyebrow'))?></div><h1><?=e(t('ins.h1a'))?><em><?=e(t('ins.h1b'))?></em></h1><p><?=e(t('ins.intro'))?></p></div><div class="stat-tiles"><div class="stat-tile t1"><span class="ico"><svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="#c9953f" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 3h11a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6z"/><path d="M6 3v18M10 8h6M10 12h6"/></svg></span><div><small><?=e(t('ins.total'))?></small><strong><?=$total?></strong></div></div><div class="stat-tile t2"><span class="ico"><svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="#d9739a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l2.700 5.600 6.100.9-4.400 4.300 1 6.100L12 17l-5.400 2.900 1-6.100L3.200 9.500l6.100-.9z"/></svg></span><div><small><?=e(t('ins.avg'))?></small><strong><?=$avgTxt?> / 5</strong></div></div><div class="stat-tile t3"><span class="ico"><?=mood_face($topMood??'','💜')?></span><div><small><?=e(t('ins.top'))?></small><strong><?=$topMood?e(mood_name($topMood)):'—'?></strong></div></div></div><?php include 'inc_jar.php'; ?><div class="chart-grid ins-split"><section class="chart-card cal-card" id="calCard"><div class="cal-head"><h2><?=e(t('cal.title'))?></h2><div class="cal-nav"><button type="button" id="calPrev" aria-label="<?=e(t('cal.prev'))?>">‹</button><b id="calMonth"></b><button type="button" id="calNext" aria-label="<?=e(t('cal.next'))?>">›</button></div></div><p><?=e(t('cal.sub'))?></p><div class="cal-week" id="calWeek"></div><div class="cal-grid" id="calGrid"></div><div class="cal-legend" id="calLegend"></div><div class="cal-detail" id="calDetail"></div></section><section class="chart-card pastel2"><h2><?=e(t('ins.chart_h'))?></h2><p><?=e(t('ins.chart_sub'))?></p><?php if(!$months):?><div class="empty"><?=e(t('ins.empty'))?></div><?php else:?><div class="chart-box"><canvas id="monthChart"></canvas></div><?php endif;?></section></div><?php if($months):?><script>
Chart.defaults.font.family="'DM Sans', sans-serif";Chart.defaults.color="#958ca5";Chart.defaults.plugins.legend.labels.usePointStyle=true;Chart.defaults.plugins.legend.labels.pointStyle="circle";
const softGrid={color:"rgba(190,178,211,.20)",drawBorder:false};
<?php if($months):?>(()=>{
const FACES=<?=json_encode(mood_faces_map(),JSON_UNESCAPED_UNICODE)?>,NAMES={5:'Керемет',4:'Жақсы',3:'Қалыпты',2:'Мұңды',1:'Мазасыз'},LBL=<?=json_encode(array_combine(['Керемет','Жақсы','Қалыпты','Мұңды','Мазасыз'],array_map('mood_name',['Керемет','Жақсы','Қалыпты','Мұңды','Мазасыз'])),JSON_UNESCAPED_UNICODE)?>;
const vals=<?=json_encode(array_map('floatval',array_column($months,'avgscore')))?>;
const imgs=vals.map(v=>{const im=new Image(40,40);im.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(FACES[NAMES[Math.max(1,Math.min(5,Math.round(v)))]]);return im});
const cv=document.getElementById('monthChart');
new Chart(cv,{type:'line',data:{labels:<?=json_encode($monthLabels,JSON_UNESCAPED_UNICODE)?>,datasets:[{label:<?=json_encode(t('ins.series'),JSON_UNESCAPED_UNICODE|JSON_HEX_TAG)?>,data:vals,
 borderColor:(c)=>{const a=c.chart.chartArea;if(!a)return '#c28be0';const g=c.chart.ctx.createLinearGradient(a.left,0,a.right,0);g.addColorStop(0,'#ffb067');g.addColorStop(.35,'#ff8fb8');g.addColorStop(.7,'#b58cf0');g.addColorStop(1,'#6fa8f5');return g},
 backgroundColor:(c)=>{const a=c.chart.chartArea;if(!a)return 'rgba(255,200,230,.2)';const g=c.chart.ctx.createLinearGradient(0,a.top,0,a.bottom);g.addColorStop(0,'rgba(255,160,200,.32)');g.addColorStop(1,'rgba(190,170,255,.02)');return g},
 fill:true,tension:.5,borderWidth:6,borderCapStyle:'round',borderJoinStyle:'round',pointStyle:imgs,pointRadius:20,pointHoverRadius:23,pointBorderWidth:0}]},
 options:{maintainAspectRatio:false,layout:{padding:{top:16,right:22,left:4,bottom:4}},interaction:{intersect:false,mode:'index'},animation:{duration:1400,easing:'easeOutElastic'},
 plugins:{legend:{display:false},tooltip:{backgroundColor:'#554b68',padding:12,cornerRadius:14,displayColors:false,callbacks:{label:(i)=>LBL[NAMES[Math.max(1,Math.min(5,Math.round(i.parsed.y)))]]+' · '+i.parsed.y+' / 5'}}},
 scales:{x:{grid:{display:false},border:{display:false},ticks:{padding:12,font:{weight:'700'}}},y:{min:0.4,max:5.6,afterBuildTicks:(ax)=>{ax.ticks=[1,2,3,4,5].map(v=>({value:v}))},ticks:{padding:10,font:{size:11,weight:'600'},callback:(v)=>LBL[NAMES[v]]||''},grid:{color:'rgba(190,178,211,.28)',borderDash:[3,6],drawBorder:false},border:{display:false}}}}});
})();<?php endif;?>
</script><?php endif;?><script>
(()=>{
const ENT=<?=json_encode((object)$cal,JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?>,
FACES=<?=json_encode(mood_faces_map(),JSON_UNESCAPED_UNICODE)?>,
MN=<?=json_encode(array_combine(mood_names(),array_map('mood_name',mood_names())),JSON_UNESCAPED_UNICODE|JSON_HEX_TAG)?>,
COL=<?=json_encode(mood_colors('dash'))?>,
MON=<?=json_encode(explode(',',t('mon.full')),JSON_UNESCAPED_UNICODE)?>,
WD=<?=json_encode(explode(',',t('cal.wd')),JSON_UNESCAPED_UNICODE)?>,
TX=<?=json_encode(['none'=>t('cal.none'),'add'=>t('cal.add'),'future'=>t('cal.future'),'emptyMonth'=>t('cal.empty_month'),'more'=>t('cal.more','{0}'),'def'=>t('note.default')],JSON_UNESCAPED_UNICODE)?>;
const $=id=>document.getElementById(id),pad=n=>String(n).padStart(2,'0'),key=(y,m,d)=>y+'-'+pad(m+1)+'-'+pad(d);
const now=new Date(),ty=now.getFullYear(),tm=now.getMonth(),tk=key(ty,tm,now.getDate());
let y=ty,m=tm,sel=tk;
$('calWeek').innerHTML=WD.map(w=>'<span>'+w+'</span>').join('');
const face=n=>FACES[n]||'<span class="cal-fb">🌱</span>';
function el(tag,cls,txt){const e=document.createElement(tag);if(cls)e.className=cls;if(txt!=null)e.textContent=txt;return e}
function render(){
 $('calMonth').textContent=MON[m]+' '+y;
 const grid=$('calGrid');grid.innerHTML='';
 const off=(new Date(y,m,1).getDay()+6)%7,days=new Date(y,m+1,0).getDate(),cnt={};
 for(let i=0;i<off;i++)grid.append(el('span','cal-d blank'));
 for(let d=1;d<=days;d++){
  const k=key(y,m,d),list=ENT[k]||[],last=list[list.length-1],future=k>tk;
  const b=el('button','cal-d'+(last?' has':'')+(k===tk?' today':'')+(k===sel?' sel':'')+(future?' future':''));b.type='button';b.dataset.k=k;
  if(last){b.style.setProperty('--c',COL[last.m]||'#e6e0f2');b.innerHTML=face(last.m);list.forEach(x=>{cnt[x.m]=(cnt[x.m]||0)+1});if(list.length>1)b.append(el('em','cal-x','×'+list.length))}
  b.prepend(el('i','',d));
  b.onclick=()=>{sel=k;render()};grid.append(b);
 }
 const lg=$('calLegend');lg.innerHTML='';
 const names=Object.keys(cnt).sort((a,b)=>cnt[b]-cnt[a]);
 if(!names.length)lg.append(el('small','',TX.emptyMonth));
 names.forEach(n=>{const c=el('span','cal-chip');c.style.setProperty('--c',COL[n]||'#e6e0f2');const f=el('b');f.innerHTML=face(n);c.append(f,el('span','',MN[n]||n),el('em','',cnt[n]));lg.append(c)});
 $('calNext').disabled=(y===ty&&m===tm);
 detail();
}
function detail(){
 const box=$('calDetail');box.innerHTML='';
 if(!sel||sel.slice(0,7)!==y+'-'+pad(m+1)){return}
 const list=ENT[sel]||[],p=sel.split('-'),title=(+p[2])+' '+MON[+p[1]-1];
 box.append(el('h4','',title));
 if(sel>tk){box.append(el('p','',TX.future));return}
 if(!list.length){box.append(el('p','',TX.none));const a=el('a','cal-add',TX.add);a.href='add.php?date='+sel;box.append(a);return}
 list.slice(-3).reverse().forEach(x=>{const r=el('div','cal-row');const f=el('b','cal-face');f.innerHTML=face(x.m);const t=el('div');t.append(el('strong','',MN[x.m]||x.m),el('p','',x.n||TX.def));r.append(f,t);box.append(r)});
 if(list.length>3)box.append(el('small','',TX.more.replace('{0}',list.length-3)));
 const a=el('a','cal-add',TX.add);a.href='add.php?date='+sel;box.append(a);
}
$('calPrev').onclick=()=>{m--;if(m<0){m=11;y--}sel=null;render()};
$('calNext').onclick=()=>{if(y===ty&&m===tm)return;m++;if(m>11){m=0;y++}sel=(y===ty&&m===tm)?tk:null;render()};
render();
})();
</script><?php require 'inc_footer.php';?>
