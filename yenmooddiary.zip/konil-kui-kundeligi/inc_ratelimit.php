<?php
// Кіру әрекеттерін шектеу (brute-force қорғанысы). Сәтсіз әрекеттер login_attempts кестесінде сақталады.
//  • бір email + бір IP: 15 минутта 5 сәтсіз әрекет
//  • бір IP (кез келген email): 15 минутта 20 сәтсіз әрекет
// Шектен асса, дұрыс құпиясөз енгізсе де, мерзім біткенше кіргізілмейді.
const LOGIN_MAX_PER_ACCOUNT = 5;
const LOGIN_MAX_PER_IP = 20;
const LOGIN_WINDOW_MIN = 15;

// Тек REMOTE_ADDR: X-Forwarded-For жалған болуы мүмкін, сондықтан сенбейміз.
function rl_ip(): string { return substr((string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'), 0, 45); }

function rl_table(): void {
 static $done = false; if ($done) return; $done = true;
 db()->exec('CREATE TABLE IF NOT EXISTS login_attempts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ip VARCHAR(45) NOT NULL,
  email VARCHAR(190) NOT NULL,
  attempted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ip_time (ip, attempted_at),
  INDEX idx_email_ip_time (email, ip, attempted_at)
 )');
}

// Бұғаттың біту уақытына дейін қалған секунд (0 = бұғат жоқ).
function rl_wait_one(string $where, array $args, int $max): int {
 $w = LOGIN_WINDOW_MIN;
 $q = db()->prepare("SELECT TIMESTAMPDIFF(SECOND, NOW(), attempted_at + INTERVAL $w MINUTE) FROM login_attempts
  WHERE $where AND attempted_at > NOW() - INTERVAL $w MINUTE ORDER BY attempted_at DESC, id DESC LIMIT 1 OFFSET " . ($max - 1));
 $q->execute($args); $v = $q->fetchColumn();
 return $v === false ? 0 : max(1, (int)$v);
}
function rl_wait(string $email, string $ip): int {
 try {
  rl_table(); $email = substr($email, 0, 190);
  return max(rl_wait_one('email=? AND ip=?', [$email, $ip], LOGIN_MAX_PER_ACCOUNT), rl_wait_one('ip=?', [$ip], LOGIN_MAX_PER_IP));
 } catch (Throwable $x) { error_log('rate-limit: ' . $x->getMessage()); return 0; } // DB қатесінде кіруді бұзбаймыз, бірақ логқа жазамыз
}
function rl_fail(string $email, string $ip): void {
 try {
  rl_table(); db()->prepare('INSERT INTO login_attempts(ip,email) VALUES(?,?)')->execute([$ip, substr($email, 0, 190)]);
  if (mt_rand(1, 50) === 1) db()->exec('DELETE FROM login_attempts WHERE attempted_at < NOW() - INTERVAL 1 DAY');
 } catch (Throwable $x) { error_log('rate-limit: ' . $x->getMessage()); }
}
function rl_clear(string $email, string $ip): void {
 try { rl_table(); db()->prepare('DELETE FROM login_attempts WHERE email=? AND ip=?')->execute([substr($email, 0, 190), $ip]); }
 catch (Throwable $x) { error_log('rate-limit: ' . $x->getMessage()); }
}
