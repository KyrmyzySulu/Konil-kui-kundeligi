<?php
// Тілді ауыстыру: POST (csrf тексеріледі), cookie жазады да, баптауларға қайтарады.
require_once 'auth.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();
 $l=$_POST['lang']??'';
 if(isset(LANGS[$l])) setcookie('lang',$l,['expires'=>time()+31536000,'path'=>'/','samesite'=>'Lax']);
}
$back=$_POST['back']??'settings.php';
go(preg_match('/^[a-z_]+\.php$/',$back)?$back:'settings.php');
