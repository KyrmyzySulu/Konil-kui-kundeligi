<?php
// Әр қолданушының жеке статусы (user_id бойынша дерекқорда сақталады).
// Бұрын статус браузердің localStorage-ында болғандықтан, бір браузердегі барлық аккаунтқа ортақ болатын.

const STATUS_IDS  = ['coffee','sleep','study','eat','walk','music','sport','game','custom'];
const PET_TYPES   = ['cat','dog','bunny'];
const PET_PLACES  = ['home','meadow','cafe','newyear','beach'];
const PET_ACTS    = ['feed','sleep','play','bath','cuddle'];

function status_table(): void {
 db()->exec('CREATE TABLE IF NOT EXISTS user_status (
  user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
  data TEXT NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_status_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
 )');
}

function status_default(): array {
 return ['st'=>null,'hist'=>[],'pet'=>['type'=>'cat','place'=>'home','act'=>'cuddle','start'=>round(microtime(true)*1000)],'bday'=>null,'water'=>['d'=>null,'n'=>0]];
}

function status_item($v){
 if(!is_array($v) || !isset($v['id']) || !in_array($v['id'], STATUS_IDS, true)) return null;
 $o=['id'=>$v['id'],'start'=>isset($v['start'])?(int)$v['start']:(int)round(microtime(true)*1000)];
 if($v['id']==='custom'){
  $t=trim(mb_substr((string)($v['text']??''),0,28));
  if($t==='') return null;
  $o['text']=$t;
 }
 return $o;
}

// Клиенттен келген деректі тексеріп, тек рұқсат етілген өрістерді қалдырады.
function status_clean($in): array {
 $d=status_default();
 if(!is_array($in)) return $d;
 $d['st']=status_item($in['st']??null);
 foreach(array_slice((array)($in['hist']??[]),0,6) as $h){ if(($x=status_item($h))) $d['hist'][]=$x; }
 $p=$in['pet']??[];
 if(is_array($p)){
  if(in_array($p['type']??'',PET_TYPES,true))   $d['pet']['type']=$p['type'];
  if(in_array($p['place']??'',PET_PLACES,true)) $d['pet']['place']=$p['place'];
  if(in_array($p['act']??'',PET_ACTS,true))     $d['pet']['act']=$p['act'];
  if(isset($p['start'])) $d['pet']['start']=(int)$p['start'];
  // Геймификация: көрсеткіштер 0–100, XP мен тиын шектеулі
  foreach(['h','f','e','c'] as $k){ if(isset($p[$k]) && is_numeric($p[$k])) $d['pet'][$k]=max(0,min(100,(int)round((float)$p[$k]))); }
  foreach(['xp','coins'] as $k){ if(isset($p[$k]) && is_numeric($p[$k])) $d['pet'][$k]=max(0,min(999999,(int)$p[$k])); }
  if(isset($p['tk']) && is_numeric($p['tk'])) $d['pet']['tk']=(int)$p['tk'];
 }
 if(isset($in['bday']) && is_string($in['bday']) && preg_match('/^\d{4}-\d{2}-\d{2}$/',$in['bday'])) $d['bday']=$in['bday'];
 // Бүгінгі су: күні (клиенттің жергілікті күні) және стақан саны
 $w=$in['water']??null;
 if(is_array($w) && isset($w['d']) && is_string($w['d']) && preg_match('/^\d{4}-\d{2}-\d{2}$/',$w['d'])) $d['water']=['d'=>$w['d'],'n'=>max(0,min(30,(int)($w['n']??0)))];
 return $d;
}

function status_load(int $uid): array {
 try{
  status_table();
  $q=db()->prepare('SELECT data FROM user_status WHERE user_id=?'); $q->execute([$uid]);
  $raw=$q->fetchColumn();
  return $raw ? status_clean(json_decode($raw,true)) : status_default();
 }catch(Throwable $x){ return status_default(); }
}

function status_save(int $uid, array $d): void {
 status_table();
 $json=json_encode(status_clean($d), JSON_UNESCAPED_UNICODE);
 $q=db()->prepare('SELECT 1 FROM user_status WHERE user_id=?'); $q->execute([$uid]);
 if($q->fetchColumn()){ $u=db()->prepare('UPDATE user_status SET data=?, updated_at=CURRENT_TIMESTAMP WHERE user_id=?'); $u->execute([$json,$uid]); }
 else { $i=db()->prepare('INSERT INTO user_status (user_id,data) VALUES (?,?)'); $i->execute([$uid,$json]); }
}
