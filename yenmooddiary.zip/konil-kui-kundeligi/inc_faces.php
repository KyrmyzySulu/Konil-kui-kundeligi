<?php
// Әр көңіл күйдің өз кейпі бар: түсі де, пішіні де әртүрлі (SVG).
function mood_face_svg($m){
 $o='stroke="#2b2230" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"';
 $ch=function($x,$y,$c='#ff8fa8'){return '<ellipse cx="'.$x.'" cy="'.$y.'" rx="3.4" ry="2.2" fill="'.$c.'" opacity=".6"/>';};
 $b='';
 switch($m){
  case 'Керемет': // күн
   $rays='';for($i=0;$i<8;$i++){$a=$i*M_PI/4;$rays.='<path d="M'.round(24+19*cos($a),1).' '.round(25+19*sin($a),1).' L'.round(24+23*cos($a),1).' '.round(25+23*sin($a),1).'" stroke="#f2a93b" stroke-width="3" stroke-linecap="round"/>';}
   $b=$rays.'<circle cx="24" cy="25" r="15.5" fill="#ffd36e" '.$o.'/><path d="M15.5 23 q3 -4.5 6 0 M26.5 23 q3 -4.5 6 0" fill="none" '.$o.'/><path d="M18.5 29 q5.5 8 11 0z" fill="#e8667f" '.$o.'/>'.$ch(14,29).$ch(34,29);break;
  case 'Жақсы': // жұмсақ квадрат-жүрек
   $b='<rect x="6.5" y="8" width="35" height="33" rx="15" fill="#ff9ec4" '.$o.'/><circle cx="17" cy="23" r="2.4" fill="#2b2230"/><circle cx="31" cy="23" r="2.4" fill="#2b2230"/><path d="M19.5 29.5 q4.5 4.5 9 0" fill="none" '.$o.'/>'.$ch(12.5,29,'#fff').$ch(35.5,29,'#fff').'<path d="M37 8.5 q2 -3 4 -1 q2 2 -4 6 q-6 -4 -4 -6 q2 -2 4 1z" fill="#ff5f8f" transform="translate(-2 -1) scale(.7)"/>';break;
  case 'Қалыпты': // мятный дөңгелек төртбұрыш
   $b='<rect x="7" y="9" width="34" height="32" rx="12" fill="#8fe3d0" '.$o.'/><circle cx="17" cy="24" r="2.4" fill="#2b2230"/><circle cx="31" cy="24" r="2.4" fill="#2b2230"/><path d="M20 31.5 h8" fill="none" '.$o.'/>'.$ch(12.5,30,'#fff').$ch(35.5,30,'#fff');break;
  case 'Мұңды': // тамшы
   $b='<path d="M24 3.5 C30 14 43 20 43 29.5 A19 16.5 0 0 1 5 29.5 C5 20 18 14 24 3.5Z" fill="#b6a8f5" '.$o.'/><circle cx="17" cy="31" r="2.4" fill="#2b2230"/><circle cx="31" cy="31" r="2.4" fill="#2b2230"/><path d="M19.5 39.5 q4.5 -4.5 9 0" fill="none" '.$o.'/><path d="M35 34 q3 4 0 6.5 q-3 -2.5 0 -6.5z" fill="#8fd0ff" stroke="#2b2230" stroke-width="1.6"/>';break;
  case 'Мазасыз': // желе
   $b='<path d="M24 7 C36 6 44 14 43 26 C42 38 34 43 24 43 C13 43 5 38 5 26 C4 14 12 8 24 7Z" fill="#8fb8f7" '.$o.'/><circle cx="16.5" cy="24" r="4.2" fill="#fff" stroke="#2b2230" stroke-width="2"/><circle cx="31.5" cy="24" r="4.2" fill="#fff" stroke="#2b2230" stroke-width="2"/><circle cx="17.2" cy="24.6" r="1.7" fill="#2b2230"/><circle cx="30.8" cy="24.6" r="1.7" fill="#2b2230"/><path d="M12 16 l8 2.5 M36 16 l-8 2.5" fill="none" '.$o.'/><path d="M18 34 q2 -3 4 0 t4 0 t4 0" fill="none" '.$o.'/><path d="M40 7 q3 4 0 6.5 q-3 -2.5 0 -6.5z" fill="#bfe6ff" stroke="#2b2230" stroke-width="1.6"/>';break;
  case 'Шаршадым': // ұйқышыл бұлт-шар
   $b='<circle cx="24" cy="26" r="18" fill="#d5b0ee" '.$o.'/><path d="M13 25 q3 3.2 6 0 M29 25 q3 3.2 6 0" fill="none" '.$o.'/><ellipse cx="24" cy="33.5" rx="3" ry="2.6" fill="#7b5a96" stroke="#2b2230" stroke-width="1.8"/>'.$ch(12,31,'#fff').$ch(36,31,'#fff').'<path d="M33 5 h6 l-6 6.5 h6" fill="none" stroke="#7b5a96" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>';break;
  case 'Ашулы': // қызыл желіктей, бу шығып тұр
   $b='<path d="M24 7 C36 7 43 14 43 26 C43 37 36 43 24 43 C12 43 5 37 5 26 C5 14 12 7 24 7Z" fill="#ff8a78" '.$o.'/><path d="M10.5 17 l9 4.5 M37.5 17 l-9 4.5" fill="none" '.$o.'/><circle cx="16.5" cy="26" r="2.4" fill="#2b2230"/><circle cx="31.5" cy="26" r="2.4" fill="#2b2230"/><path d="M17.5 37 q6.5 -6 13 0" fill="none" '.$o.'/>'.$ch(11.5,32,'#ffd1c8').$ch(36.5,32,'#ffd1c8').'<path d="M33 4.5 q3.5 .5 3.5 4 M43 4.5 q-3.5 .5 -3.5 4 M33 14.5 q3.5 -.5 3.5 -4 M43 14.5 q-3.5 -.5 -3.5 -4" fill="none" stroke="#e0412f" stroke-width="2.2" stroke-linecap="round"/>';break;
  case 'Ғашықпын': // жүрек
   $b='<path d="M24 42.5 C5 30 3 16 12.5 10.5 C18 7.5 23 10.5 24 15 C25 10.5 30 7.5 35.5 10.5 C45 16 43 30 24 42.5Z" fill="#ff7fa8" '.$o.'/><path d="M13.5 22 q3 -4.5 6 0 M28.5 22 q3 -4.5 6 0" fill="none" '.$o.'/><path d="M20.5 28.5 q3.5 4 7 0" fill="none" '.$o.'/>'.$ch(12.5,28,'#fff').$ch(35.5,28,'#fff').'<path d="M40 5 q1.5 -2.5 3.2 -.8 q1.7 1.7 -3.2 4.6 q-4.9 -2.9 -3.2 -4.6 q1.7 -1.7 3.2 .8z" fill="#ff5f8f" stroke="#2b2230" stroke-width="1.4"/>';break;
  case 'Тыныш': // тас-жапырақ, көзі жұмық
   $b='<ellipse cx="24" cy="28" rx="19" ry="15.5" fill="#a8e6a3" '.$o.'/><path d="M13 26 h7 M28 26 h7" fill="none" '.$o.'/><path d="M20 33 q4 3 8 0" fill="none" '.$o.'/>'.$ch(11.5,31,'#fff').$ch(36.5,31,'#fff').'<path d="M23 12.5 C22 6 29 3.5 35 4.5 C35.5 10.5 31 14.5 23 12.5Z" fill="#6cc97a" '.$o.'/><path d="M24 12 q5 -2 8 -6" fill="none" stroke="#2b2230" stroke-width="1.6" stroke-linecap="round"/>';break;
  case 'Таңғалдым': // таңдана ашылған көз бен ауыз
   $b='<circle cx="24" cy="27" r="17.5" fill="#ffbf80" '.$o.'/><path d="M10.5 15.5 q5 -4 9 0 M28.5 15.5 q5 -4 9 0" fill="none" '.$o.'/><circle cx="17" cy="24" r="4.4" fill="#fff" stroke="#2b2230" stroke-width="2"/><circle cx="31" cy="24" r="4.4" fill="#fff" stroke="#2b2230" stroke-width="2"/><circle cx="17" cy="24.4" r="1.8" fill="#2b2230"/><circle cx="31" cy="24.4" r="1.8" fill="#2b2230"/><ellipse cx="24" cy="35.5" rx="3.3" ry="4.4" fill="#7a3b3b" '.$o.'/>'.$ch(10.5,31).$ch(37.5,31).'<path d="M42 6 v5 M39.5 8.5 h5 M6 6 v4 M4 8 h4" fill="none" stroke="#f2a93b" stroke-width="2" stroke-linecap="round"/>';break;
  case 'Жалғызбын': // түнгі ай астында, жалғыз
   $b='<circle cx="22" cy="28" r="16.5" fill="#a9b6d3" '.$o.'/><circle cx="16" cy="27" r="4" fill="#fff" stroke="#2b2230" stroke-width="2"/><circle cx="29" cy="27" r="4" fill="#fff" stroke="#2b2230" stroke-width="2"/><circle cx="17.3" cy="28" r="1.7" fill="#2b2230"/><circle cx="30.3" cy="28" r="1.7" fill="#2b2230"/><path d="M17 37 q5 -2.4 10 0" fill="none" '.$o.'/><path d="M13.5 20 l5 -1.2 M31.5 20 l-5 -1.2" fill="none" '.$o.'/><path d="M40 4 a6 6 0 1 0 5 8.5 a4.6 4.6 0 1 1 -5 -8.5z" fill="#ffe08a" stroke="#2b2230" stroke-width="1.6" stroke-linejoin="round"/>';break;
  case 'Мақтанышпын': // тәж киген
   $b='<circle cx="24" cy="29" r="15.5" fill="#d4ea6b" '.$o.'/><path d="M13.5 15 l3.5 -9 l7 5.5 l7 -5.5 l3.5 9z" fill="#ffd36e" '.$o.'/><circle cx="17" cy="28" r="2.4" fill="#2b2230"/><circle cx="31" cy="28" r="2.4" fill="#2b2230"/><path d="M13.5 22.5 l6 -1.4 M34.5 22.5 l-6 -1.4" fill="none" '.$o.'/><path d="M17.5 35 q7 5.5 13 -1.2" fill="none" '.$o.'/>'.$ch(12,33,'#fff').$ch(36,33,'#fff');break;
  default: return '';
 }
 return '<svg class="mf" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" aria-hidden="true">'.$b.'</svg>';
}
// Барлық көңіл күйдің бірыңғай тізімі: реті, баллы (1–5), эмодзи және әр бетке арналған түстер.
// Жаңа көңіл күй қосу үшін: осында жол + mood_face_svg() ішіне кейіп + lang/*.php ішіне 'mood.<атау>'.
function mood_registry(){
 static $r=null; if($r!==null)return $r;
 //                    балл  эмодзи  flask      bubble     jar        dash
 $r=[
  'Керемет'    =>['score'=>5,'emoji'=>'😄','flask'=>'#ffd36e','bubble'=>'#ffc83d','jar'=>'#ff9a7a','dash'=>'#f4a58e'],
  'Жақсы'      =>['score'=>4,'emoji'=>'🙂','flask'=>'#ff9ec4','bubble'=>'#ff7fb3','jar'=>'#ff7fb0','dash'=>'#d77aa6'],
  'Ғашықпын'   =>['score'=>5,'emoji'=>'🥰','flask'=>'#ff6b9a','bubble'=>'#ee4a82','jar'=>'#ff6b9a','dash'=>'#f2a3c0'],
  'Мақтанышпын'=>['score'=>5,'emoji'=>'😎','flask'=>'#c5df5a','bubble'=>'#b4d336','jar'=>'#c5df5a','dash'=>'#e0eab0'],
  'Тыныш'      =>['score'=>4,'emoji'=>'😌','flask'=>'#8fd694','bubble'=>'#6cc97a','jar'=>'#8fd694','dash'=>'#bfe3c4'],
  'Қалыпты'    =>['score'=>3,'emoji'=>'😐','flask'=>'#6fdcc8','bubble'=>'#3fd1b5','jar'=>'#ffd36e','dash'=>'#f0d3ad'],
  'Таңғалдым'  =>['score'=>3,'emoji'=>'😲','flask'=>'#ffab5e','bubble'=>'#ff9632','jar'=>'#ffb066','dash'=>'#f7cfa0'],
  'Мұңды'      =>['score'=>2,'emoji'=>'😔','flask'=>'#9d8cf0','bubble'=>'#8b78ee','jar'=>'#9d8cf0','dash'=>'#c8c4d0'],
  'Жалғызбын'  =>['score'=>2,'emoji'=>'🥺','flask'=>'#8e9bb5','bubble'=>'#6f7fa3','jar'=>'#8e9bb5','dash'=>'#c3cadb'],
  'Шаршадым'   =>['score'=>2,'emoji'=>'😴','flask'=>'#c9a0e8','bubble'=>'#b57de0','jar'=>'#c9a0e8','dash'=>'#e6c5d4'],
  'Мазасыз'    =>['score'=>1,'emoji'=>'😟','flask'=>'#6fa8f5','bubble'=>'#5b97f2','jar'=>'#6fa8f5','dash'=>'#aeb8d1'],
  'Ашулы'      =>['score'=>1,'emoji'=>'😠','flask'=>'#ff7a6b','bubble'=>'#f2543f','jar'=>'#ff6f61','dash'=>'#f2a094'],
 ];
 return $r;
}
function mood_names(){ return array_keys(mood_registry()); }
function mood_scores(){ return array_map(fn($x)=>$x['score'],mood_registry()); }
function mood_colors($k){ return array_map(fn($x)=>$x[$k],mood_registry()); }
function mood_emoji($m){ return mood_registry()[$m]['emoji']??'🌱'; }
function mood_name($m){ $k='mood.'.$m; $s=t($k); return $s===$k?(string)$m:$s; }
// Санат дерекқорда қазақша 'Жалпы' ретінде сақталады, көрсету тілге қарай.
function cat_name($c){ $c=trim((string)$c); return ($c===''||$c==='Жалпы')?t('cat.general'):$c; }
function cat_store($c){ $c=trim((string)$c); if($c==='')return 'Жалпы'; foreach(['kk','ru','en'] as $l){ if($c===(lang_dict($l)['cat.general']??null)) return 'Жалпы'; } return $c; }
function mood_face($m,$fallback='🌱'){ $s=mood_face_svg($m); return $s!==''?$s:$fallback; }
function mood_faces_map(){ $r=[]; foreach(mood_names() as $m)$r[$m]=mood_face_svg($m); return $r; }
