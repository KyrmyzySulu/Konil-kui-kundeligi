<?php static $wxOnce=false; ?>
<section class="wx-card" data-kind="clear">
 <svg class="wx-deco" viewBox="0 0 300 120" aria-hidden="true"><path d="M20 96 C80 20 190 20 280 70" fill="none" stroke="#ffffff66" stroke-width="3" stroke-dasharray="6 7" stroke-linecap="round"/><circle cx="262" cy="22" r="26" fill="#ffffff1f"/><circle cx="40" cy="100" r="34" fill="#ffffff14"/></svg>
 <div class="wx-top"><button type="button" class="wx-place" title="<?=e(t('wx.place_title'))?>">📍 <span class="wx-place-name"><?=e(t('wx.default_place'))?></span></button><span class="wx-time">--:--</span></div>
 <div class="wx-main">
  <svg class="wx-cat" viewBox="0 0 120 130" aria-hidden="true">
   <ellipse cx="60" cy="112" rx="30" ry="16" fill="#fff3df" stroke="#2b2230" stroke-width="4"/>
   <path d="M26 54 L22 18 L52 38 Z" fill="#fff3df" stroke="#2b2230" stroke-width="4" stroke-linejoin="round"/><path d="M94 54 L98 18 L68 38 Z" fill="#fff3df" stroke="#2b2230" stroke-width="4" stroke-linejoin="round"/>
   <path d="M29 44 L28 28 L40 37 Z" fill="#f7b6bf"/><path d="M91 44 L92 28 L80 37 Z" fill="#f7b6bf"/>
   <ellipse cx="60" cy="72" rx="42" ry="35" fill="#fff3df" stroke="#2b2230" stroke-width="4"/>
   <path d="M60 40 v9 M50 42 l2 8 M70 42 l-2 8" stroke="#c98a55" stroke-width="4" stroke-linecap="round"/>
   <g class="wx-eyes"><ellipse cx="44" cy="74" rx="4.5" ry="6" fill="#2b2230"/><ellipse cx="76" cy="74" rx="4.5" ry="6" fill="#2b2230"/><circle cx="45.5" cy="72" r="1.8" fill="#fff"/><circle cx="77.5" cy="72" r="1.8" fill="#fff"/></g>
   <g class="wx-eyes-closed"><path d="M38 76 q6 -8 12 0 M70 76 q6 -8 12 0" stroke="#2b2230" stroke-width="3.5" fill="none" stroke-linecap="round"/></g>
   <ellipse cx="34" cy="84" rx="7" ry="4.5" fill="#f7a8b4" opacity=".7"/><ellipse cx="86" cy="84" rx="7" ry="4.5" fill="#f7a8b4" opacity=".7"/>
   <path d="M57 82 h6 l-3 4 z" fill="#f08aa0"/><path d="M60 86 v3 M60 89 q-5 5 -9 1 M60 89 q5 5 9 1" stroke="#2b2230" stroke-width="3" fill="none" stroke-linecap="round"/>
   <g class="acc acc-rain"><path d="M6 44 Q60 -14 114 44 Q104 38 94 44 Q84 38 74 44 Q67 38 60 44 Q53 38 46 44 Q36 38 26 44 Q16 38 6 44 Z" fill="#e8445a" stroke="#7b1f2e" stroke-width="3" stroke-linejoin="round"/><path d="M60 44 V22" stroke="#7b1f2e" stroke-width="3"/><path d="M96 46 V104 q0 8 -8 8" fill="none" stroke="#7b1f2e" stroke-width="4" stroke-linecap="round"/></g>
   <g class="acc acc-sun"><rect x="29" y="66" width="26" height="16" rx="6" fill="#2b2230"/><rect x="65" y="66" width="26" height="16" rx="6" fill="#2b2230"/><path d="M55 72 h10" stroke="#2b2230" stroke-width="3"/><path d="M33 69 l7 0" stroke="#fff" stroke-width="2" stroke-linecap="round" opacity=".7"/></g>
   <g class="acc acc-scarf"><path d="M24 96 Q60 114 96 96 L98 108 Q60 126 22 108 Z" fill="#e8445a" stroke="#7b1f2e" stroke-width="3" stroke-linejoin="round"/><rect x="78" y="108" width="14" height="20" rx="5" fill="#e8445a" stroke="#7b1f2e" stroke-width="3"/></g>
   <g class="acc acc-hat"><path d="M22 52 Q60 -6 98 52 Z" fill="#6fa8f5" stroke="#2f5da8" stroke-width="3" stroke-linejoin="round"/><rect x="20" y="46" width="80" height="12" rx="6" fill="#fff" stroke="#2f5da8" stroke-width="3"/><circle cx="60" cy="8" r="9" fill="#fff" stroke="#2f5da8" stroke-width="3"/></g>
   <g class="acc acc-night"><text x="92" y="30" font-size="16" fill="#fff" font-weight="800">z</text><text x="102" y="18" font-size="12" fill="#fff" font-weight="800">z</text></g>
  </svg>
  <div class="wx-temp"><b class="wx-deg">--°</b><small class="wx-desc"><?=e(t('wx.loading'))?></small><small class="wx-feel"></small></div>
  <div class="wx-icon">⛅</div>
 </div>
 <div class="wx-advice"><h4><?=e(t('wx.advice_h'))?></h4><ul class="wx-list"></ul><button type="button" class="wx-more"><?=e(t('wx.more'))?></button></div>
</section>
<?php if(!$wxOnce): $wxOnce=true;
$wxT=['a'=>[],'d'=>[],'feel'=>t('wx.feel'),'city'=>t('wx.your_city'),'off'=>t('wx.offline'),'den'=>t('wx.denied'),'def'=>t('wx.default_place'),'loc'=>['kk'=>'kk-KZ','ru'=>'ru-RU','en'=>'en-GB'][lang()],'lang'=>lang()];
foreach(['clear','cloud','rain','thunder','snow','fog','hot','cold','night'] as $wk){ $wxT['a'][$wk]=explode('|',t('wx.a.'.$wk)); $wxT['d'][$wk]=t('wx.d.'.$wk); }
?>
<script>
(()=>{
const WT=<?=json_encode($wxT,JSON_UNESCAPED_UNICODE|JSON_HEX_TAG)?>;
const cards=document.querySelectorAll('.wx-card');if(!cards.length)return;
const A=WT.a;
const DESC=WT.d;
const ICON={clear:'☀️',cloud:'⛅',rain:'🌧️',thunder:'⛈️',snow:'❄️',fog:'🌫️',hot:'🔥',cold:'🥶',night:'🌙'};
function kindOf(code,t,day){let k='clear';if(code>=95)k='thunder';else if((code>=51&&code<=67)||(code>=80&&code<=82))k='rain';else if((code>=71&&code<=77)||code===85||code===86)k='snow';else if(code===45||code===48)k='fog';else if(code===3||code===2)k='cloud';
 if(k==='clear'||k==='cloud'){if(t>=29)k='hot';else if(t<=3)k='cold';else if(!day)k='night'}return k}
let state=null,tz=undefined;
function pick(kind){const pool=A[kind].slice();const h=new Date().getHours();if(kind!=='night'&&(h>=22||h<5)){pool.unshift(...A.night.slice(0,2))}
 for(let i=pool.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[pool[i],pool[j]]=[pool[j],pool[i]]}return pool.slice(0,3)}
function render(){if(!state)return;const k=state.kind;cards.forEach(c=>{c.dataset.kind=k;c.querySelector('.wx-deg').textContent=Math.round(state.t)+'°';c.querySelector('.wx-desc').textContent=DESC[k];c.querySelector('.wx-feel').textContent=WT.feel.replace('{0}',Math.round(state.feel)).replace('{1}',Math.round(state.wind));c.querySelector('.wx-icon').textContent=ICON[k];c.querySelector('.wx-place-name').textContent=state.place;
 c.querySelector('.wx-list').innerHTML=pick(k).map(x=>'<li>'+x+'</li>').join('')})}
function clock(){const t=new Date().toLocaleTimeString(WT.loc,{hour:'2-digit',minute:'2-digit',hour12:false,timeZone:tz});cards.forEach(c=>c.querySelector('.wx-time').textContent=t)}
async function load(lat,lon,place){try{const r=await fetch('https://api.open-meteo.com/v1/forecast?latitude='+lat+'&longitude='+lon+'&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,is_day&timezone=auto');const j=await r.json();const c=j.current;tz=j.timezone;
  state={t:c.temperature_2m,feel:c.apparent_temperature,wind:c.wind_speed_10m,kind:kindOf(c.weather_code,c.temperature_2m,c.is_day===1),place:place||WT.city};
  if(!place){try{const g=await (await fetch('https://api.bigdatacloud.net/data/reverse-geocode-client?latitude='+lat+'&longitude='+lon+'&localityLanguage='+WT.lang)).json();state.place=g.city||g.locality||WT.city}catch(e){}}
  render();clock()}catch(e){cards.forEach(c=>c.querySelector('.wx-desc').textContent=WT.off)}}
let loc=null;try{loc=JSON.parse(localStorage.getItem('wxLoc:'+window.YEN_UID)||'null')}catch(e){}
if(loc)load(loc.lat,loc.lon,loc.place);else load(44.85,65.51,WT.def);
cards.forEach(c=>{c.querySelector('.wx-more').addEventListener('click',()=>{if(!state)return;const ul=c.querySelector('.wx-list');ul.innerHTML=pick(state.kind).map(x=>'<li>'+x+'</li>').join('');ul.classList.remove('swap');void ul.offsetWidth;ul.classList.add('swap')});
 c.querySelector('.wx-place').addEventListener('click',()=>{if(!navigator.geolocation){return}navigator.geolocation.getCurrentPosition(p=>{const l={lat:p.coords.latitude,lon:p.coords.longitude,place:''};try{localStorage.setItem('wxLoc:'+window.YEN_UID,JSON.stringify(l))}catch(e){}load(l.lat,l.lon,'')},()=>{c.querySelector('.wx-desc').textContent=WT.den})})});
setInterval(clock,20000);
})();
</script>
<?php endif; ?>
