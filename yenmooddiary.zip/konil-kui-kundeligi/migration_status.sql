USE mood_journal;
-- Әр қолданушының жеке статусы. Кесте бет ашылғанда автоматты түрде де жасалады.
CREATE TABLE IF NOT EXISTS user_status (
 user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
 data TEXT NOT NULL,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_status_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
