<?php
require_once 'auth.php'; require_login(); csrf_check(); $uid=current_user()['id'];
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='delete'){
 $q=db()->prepare('DELETE FROM mood_entries WHERE id=? AND user_id=?');$q->execute([(int)($_POST['id']??0),$uid]);go('history.php?deleted=1');
}
$search=trim($_GET['q']??'');$mood=$_GET['mood']??'';$from=$_GET['from']??'';$to=$_GET['to']??'';$sort=$_GET['sort']??'new';
$where=['user_id=?'];$args=[$uid];
if($search!==''){$where[]='(note LIKE ? OR category LIKE ?)';$args[]='%'.$search.'%';$args[]='%'.$search.'%';}
$moods=mood_names();if(in_array($mood,$moods,true)){$where[]='mood=?';$args[]=$mood;}
if(preg_match('/^\d{4}-\d{2}-\d{2}$/',$from)){$where[]='entry_date>=?';$args[]=$from;}
if(preg_match('/^\d{4}-\d{2}-\d{2}$/',$to)){$where[]='entry_date<=?';$args[]=$to;}
$order=$sort==='old'?'entry_date ASC,id ASC':($sort==='score'?'score DESC,entry_date DESC':'entry_date DESC,id DESC');
$sql=' FROM mood_entries WHERE '.implode(' AND ',$where);$q=db()->prepare('SELECT COUNT(*)'.$sql);$q->execute($args);$total=(int)$q->fetchColumn();$per=6;$pages=max(1,(int)ceil($total/$per));$page=max(1,min($pages,(int)($_GET['page']??1)));$offset=($page-1)*$per;
$q=db()->prepare('SELECT *'.$sql." ORDER BY $order LIMIT $per OFFSET $offset");$q->execute($args);$rows=$q->fetchAll();
$q=db()->prepare("SELECT COUNT(*) FROM mood_entries WHERE user_id=? AND entry_date>=DATE_FORMAT(CURDATE(),'%Y-%m-01')");$q->execute([$uid]);$monthCnt=(int)$q->fetchColumn();
$q=db()->prepare('SELECT mood,COUNT(*) n FROM mood_entries WHERE user_id=? GROUP BY mood ORDER BY n DESC LIMIT 1');$q->execute([$uid]);$topRow=$q->fetch();$topMood=$topRow['mood']??'';
$title=t('nav.history');require 'inc_header.php';
function pageUrl($n){$p=$_GET;$p['page']=$n;return '?'.http_build_query($p);}
?>
<div class="page-intro"><div class="eyebrow"><?=e(t('hist.eyebrow'))?></div><h1><?=e(t('hist.h1'))?> <em>♡</em></h1><p><?=e(t('hist.intro'))?></p></div>
<?php foreach(['saved'=>t('hist.saved'),'updated'=>t('hist.updated'),'deleted'=>t('hist.deleted')] as $k=>$v):if(isset($_GET[$k])):?><div class="success">✓ <?=e($v)?></div><?php endif;endforeach;?>
<div class="rf-summary"><div><small><?=e(t('hist.month'))?></small><b><?=e(t('hist.n_entries',$monthCnt))?></b></div><div><small><?=e(t('hist.top'))?></small><b><?=$topMood!==''?mood_face($topMood).' '.e(mood_name($topMood)):'—'?></b></div><div><small><?=e(t('hist.found'))?></small><b><?=$total?></b></div></div>
<?php include 'inc_pets.php'; ?>
<form class="filter-bar" method="get"><input name="q" placeholder="<?=e(t('hist.search_ph'))?>" value="<?=e($search)?>"><select name="mood"><option value=""><?=e(t('hist.all_moods'))?></option><?php foreach($moods as $m):?><option value="<?=e($m)?>" <?=$mood===$m?'selected':''?>><?=e(mood_name($m))?></option><?php endforeach;?></select><input type="date" name="from" aria-label="<?=e(t('hist.from'))?>" value="<?=e($from)?>"><input type="date" name="to" aria-label="<?=e(t('hist.to'))?>" value="<?=e($to)?>"><select name="sort"><option value="new" <?=$sort==='new'?'selected':''?>><?=e(t('hist.sort_new'))?></option><option value="old" <?=$sort==='old'?'selected':''?>><?=e(t('hist.sort_old'))?></option><option value="score" <?=$sort==='score'?'selected':''?>><?=e(t('hist.sort_score'))?></option></select><button class="btn primary"><?=e(t('hist.search'))?></button><a class="btn soft" href="history.php"><?=e(t('hist.clear'))?></a></form>
<div class="section-head"><h2><?=e(t('hist.results'))?> <span class="count"><?=$total?></span></h2><a class="btn primary" href="add.php"><?=e(t('hist.new'))?></a></div>
<div class="entry-list"><?php if(!$rows):?><div class="empty"><div>📖</div><b><?=e(t('hist.none'))?></b><p><?=e(t('hist.none_sub'))?></p></div><?php else:foreach($rows as $r):?><article class="entry-row" data-mood="<?=e($r['mood'])?>"><div class="mood-emoji"><?=mood_face($r['mood'])?></div><div class="entry-info"><b><?=e(mood_name($r['mood']))?> <small class="category-tag"><?=e(cat_name($r['category']??''))?></small></b><p><?=nl2br(e($r['note']?:t('note.default')))?></p></div><time><?=e(date('d.m.Y',strtotime($r['entry_date'])))?></time><a class="icon-action" href="edit.php?id=<?=$r['id']?>" title="<?=e(t('hist.edit'))?>">✎</a><form method="post" onsubmit="return confirm(<?=e(json_encode(t('hist.confirm'),JSON_UNESCAPED_UNICODE))?>)"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="icon-action danger" title="<?=e(t('hist.del'))?>">×</button></form></article><?php endforeach;endif;?></div>
<?php if($pages>1):?><nav class="pagination"><?php if($page>1):?><a href="<?=e(pageUrl($page-1))?>"><?=e(t('hist.prev'))?></a><?php endif;?><span><?=$page?> / <?=$pages?></span><?php if($page<$pages):?><a href="<?=e(pageUrl($page+1))?>"><?=e(t('hist.next'))?></a><?php endif;?></nav><?php endif;?>
<?php require 'inc_footer.php'; ?>