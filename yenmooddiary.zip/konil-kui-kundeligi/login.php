<?php require_once 'auth.php'; require_once 'inc_ratelimit.php'; if(logged_in()) go('dashboard.php'); $err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $email=strtolower(trim((string)($_POST['email']??''))); $pass=(string)($_POST['password']??''); $ip=rl_ip();
 $wait=rl_wait($email,$ip);
 if($wait>0) $err=t('auth.err_locked',(int)ceil($wait/60));
 else {
  $q=db()->prepare('SELECT * FROM users WHERE email=?'); $q->execute([$email]); $u=$q->fetch();
  if($u && password_verify($pass,$u['password'])){ rl_clear($email,$ip); session_regenerate_id(true); $_SESSION['user_id']=$u['id']; $_SESSION['user_name']=$u['name']; go('dashboard.php'); }
  else { rl_fail($email,$ip); $err=t('auth.err_login'); }
 }
}
?><!doctype html><html lang="<?=e(lang())?>"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e(t('auth.login_title'))?> · <?=e(t('app.name'))?></title><link rel="stylesheet" href="assets/css/style.css?v=20261124-v104"><link rel="stylesheet" href="assets/css/refresh.css?v=1"></head><body class="auth-page"><div class="auth-card"><form class="auth-lang" method="post" action="lang.php"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="back" value="login.php"><?php foreach(LANGS as $lc=>$ln):?><button type="submit" name="lang" value="<?=e($lc)?>" title="<?=e($ln)?>"<?=$lc===lang()?' class="on"':''?>><?=e(strtoupper($lc))?></button><?php endforeach;?></form><a class="brand" href="index.php"><span class="brand-mark">☼</span> yen</a><div class="eyebrow"><?=e(t('auth.login_eyebrow'))?></div><h1><?=e(t('auth.login_h1'))?></h1><p class="muted"><?=e(t('auth.login_sub'))?></p><?php if($err):?><div class="alert"><?=e($err)?></div><?php endif;?><form method="post"><label><?=e(t('auth.email'))?><input type="email" name="email" required placeholder="you@example.com"></label><label><?=e(t('auth.pass'))?><input type="password" name="password" required placeholder="<?=e(t('auth.pass_ph'))?>"></label><button class="btn primary full"><?=e(t('auth.login_btn'))?> <span>→</span></button></form><p class="auth-foot"><?=e(t('auth.no_acc'))?> <a href="register.php"><?=e(t('auth.to_reg'))?></a></p><small class="privacy"><?=e(t('auth.privacy_login'))?></small></div></body></html>
