<?php
function is_https(){ return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') || (($_SERVER['SERVER_PORT']??'')==='443') || strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']??'')==='https'; }
if (session_status() === PHP_SESSION_NONE) {
 ini_set('session.use_strict_mode','1'); ini_set('session.use_only_cookies','1');
 // secure: HTTPS-те ғана қосылады (localhost-та http-мен жұмыс істей береді)
 session_set_cookie_params(['lifetime'=>0,'path'=>'/','httponly'=>true,'secure'=>is_https(),'samesite'=>'Lax']);
 session_start();
}
require_once __DIR__.'/i18n.php';
require_once __DIR__.'/api/db.php';
require_once __DIR__.'/inc_faces.php';
function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function logged_in(){ return !empty($_SESSION['user_id']); }
function require_login(){ if(!logged_in()){ header('Location: login.php'); exit; } }
function current_user(){ return ['id'=>$_SESSION['user_id']??0,'name'=>$_SESSION['user_name']??'']; }
// Күн пішімі де, нақты күнтізбелік күн де дұрыс па (2026-99-99 өтпейді).
function valid_date($d){ return is_string($d) && preg_match('/^(\d{4})-(\d{2})-(\d{2})$/',$d,$m) && checkdate((int)$m[2],(int)$m[3],(int)$m[1]); }
function go($url){ header('Location: '.$url); exit; }

function csrf_token(){ if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
// Токен бос болса да өтіп кетпеуі үшін: сессияда токен болуы міндетті (бос == бос қатесі жабылды).
function csrf_check(){ if($_SERVER['REQUEST_METHOD']==='POST'){ $s=(string)($_SESSION['csrf']??''); if($s==='' || !hash_equals($s,(string)($_POST['csrf']??''))){ http_response_code(403); exit(t('err.csrf')); } } }

function gender_picker($selected='female',$translate=true){
 $tr=function($k,$kk) use($translate){return $translate?t($k):$kk;};
 $opts=['female'=>[$tr('g.f','Қыз'),'♀'],'male'=>[$tr('g.m','Ұл'),'♂']];
 $h='<fieldset class="gender-field"><legend><b>'.$tr('g.q','Сен кімсің? ✨').'</b><small>'.$tr('g.sub','Саған лайық кеңестер таңдаймыз').'</small></legend>';
 foreach($opts as $v=>$o){
  $h.='<label class="gender-choice"><input type="radio" name="gender" value="'.$v.'"'.($selected===$v?' checked':'').'><span>'.$o[1].'</span><b>'.$o[0].'</b></label>';
 }
 return $h.'</fieldset><script>document.querySelectorAll("input[name=gender]").forEach(function(r){r.addEventListener("change",function(){document.body.classList.toggle("theme-male",r.value==="male")});if(r.checked)document.body.classList.toggle("theme-male",r.value==="male")});</script>';
}

function quote_pack($gender){ return explode('|',t($gender==='male'?'quotes.m':'quotes.f')); }
function user_gender(){ if(!logged_in())return null; static $g=null; if($g===null){ try{$q=db()->prepare('SELECT gender FROM users WHERE id=?');$q->execute([$_SESSION['user_id']]);$g=$q->fetchColumn()?:'female';}catch(Throwable $x){$g='female';} } return $g; }
