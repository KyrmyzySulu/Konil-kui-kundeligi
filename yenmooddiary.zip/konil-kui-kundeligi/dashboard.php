<?php
require_once 'auth.php'; require_login();
$uid=current_user()['id'];
$uq=db()->prepare('SELECT gender FROM users WHERE id=?');$uq->execute([$uid]);$gender=$uq->fetchColumn() ?: 'female';
$heroImage=$gender==='male'?'assets/images/avatar-boy.png':'assets/images/avatar-girl.png';
$personalTip=t($gender==='male'?'dash.tip_m':'dash.tip_f');
$quotes=quote_pack($gender);$qi=(int)date('z')%count($quotes);
$q=db()->prepare('SELECT COUNT(*) total, AVG(score) avgscore FROM mood_entries WHERE user_id=?');$q->execute([$uid]);$stats=$q->fetch();
$q=db()->prepare('SELECT * FROM mood_entries WHERE user_id=? ORDER BY entry_date DESC,id DESC LIMIT 5');$q->execute([$uid]);$recent=$q->fetchAll();
$q=db()->prepare('SELECT mood,COUNT(*) n FROM mood_entries WHERE user_id=? AND entry_date>=DATE_SUB(CURDATE(),INTERVAL 7 DAY) GROUP BY mood ORDER BY n DESC LIMIT 1');$q->execute([$uid]);$top=$q->fetch();
$q=db()->prepare('SELECT avatar FROM users WHERE id=?');$q->execute([$uid]);$avatar=$q->fetchColumn();
$moods=array_map(fn($x)=>[$x['emoji'],$x['dash']],mood_registry());
$title=t('nav.home'); require 'inc_header.php';
?>
<section class="yen-top">
 <div><div class="yen-brand">yen</div><h1><?=e(t('dash.hello',current_user()['name']))?></h1></div>
 <a class="profile-shortcut" href="profile.php"><?php if($avatar && is_file(__DIR__.'/'.$avatar)):?><img src="<?=e($avatar)?>" alt="<?=e(t('dash.profile_alt'))?>"><?php else:?><span><?=e(mb_strtoupper(mb_substr(current_user()['name'],0,1)))?></span><?php endif;?><b><?=e(current_user()['name'])?></b><small><?=e(t('dash.open_profile'))?></small></a>
</section>
<div class="yen-dashboard">
 <main class="yen-main-column">
  <section class="yen-first-row">
   <div class="yen-illustration is-<?=$gender==='male'?'male':'female'?>"><img src="<?=e($heroImage)?>" alt="<?=e(t('dash.hero_alt'))?>"><div class="illustration-caption"><?=e(t('dash.hero_cap'))?></div></div>
   <div class="yen-moods"><h2><?=e(t('dash.feel'))?></h2><div class="yen-mood-grid">
   <?php foreach($moods as $m=>$v):?><a class="yen-mood" href="add.php?mood=<?=urlencode($m)?>"><span style="--mood-color:<?=$v[1]?>"><?=mood_face($m)?></span><small><?=e(mood_name($m))?></small></a><?php endforeach;?>
   </div><a class="yen-text-link" href="add.php"><?=e(t('dash.write'))?></a></div>
  </section>
  <h2 class="yen-section-title"><?=e(t('dash.purr_h'))?></h2>
  <section class="cat-card" id="catCard">
   <svg class="cat-room" viewBox="0 0 800 270" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
    <defs><linearGradient id="wall" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0c9"/><stop offset="1" stop-color="#fbd9a3"/></linearGradient></defs>
    <rect width="800" height="270" fill="url(#wall)"/>
    <g fill="#f7c98a" opacity=".55"><circle cx="40" cy="30" r="4"/><circle cx="120" cy="60" r="4"/><circle cx="260" cy="26" r="4"/><circle cx="330" cy="80" r="4"/><circle cx="470" cy="34" r="4"/><circle cx="520" cy="96" r="4"/><circle cx="700" cy="30" r="4"/><circle cx="760" cy="100" r="4"/></g>
    <rect x="70" y="92" width="190" height="12" rx="5" fill="#c58555"/>
    <g><rect x="92" y="62" width="12" height="30" rx="3" fill="#8fb9e8"/><rect x="106" y="68" width="12" height="24" rx="3" fill="#f2a5b5"/><rect x="120" y="58" width="12" height="34" rx="3" fill="#f5d36b"/></g>
    <g><path d="M190 92 h46 l-6 -34 h-34 z" fill="#d9644f" stroke="#7b3b2c" stroke-width="3" stroke-linejoin="round"/><path d="M213 58 q-14 -22 -26 -14 M213 58 q4 -26 18 -22 M213 58 q18 -10 28 4" stroke="#4f9a4a" stroke-width="5" fill="none" stroke-linecap="round"/><circle cx="187" cy="44" r="7" fill="#f58aa8"/><circle cx="231" cy="36" r="7" fill="#ffd34d"/><circle cx="241" cy="62" r="7" fill="#f58aa8"/></g>
    <g><rect x="565" y="32" width="130" height="112" rx="14" fill="#c58555"/><rect x="574" y="41" width="112" height="94" rx="8" fill="#bfe4ff"/><path d="M630 41 v94 M574 88 h112" stroke="#c58555" stroke-width="6"/><circle cx="600" cy="64" r="11" fill="#ffe27a"/><path d="M642 80 q6 -12 18 -6 q12 -6 18 6 z" fill="#fff"/></g>
    <rect x="0" y="196" width="800" height="74" fill="#e8a56a"/><path d="M0 222 H800 M0 248 H800" stroke="#d9904f" stroke-width="3"/>
    <ellipse cx="400" cy="238" rx="230" ry="28" fill="#ffe08a" stroke="#f2c25a" stroke-width="3"/>
    <g><rect x="600" y="176" width="118" height="62" rx="24" fill="#8fd16a" stroke="#5aa042" stroke-width="3"/><path d="M628 190 v34 M659 188 v38 M690 190 v34" stroke="#6bb852" stroke-width="3" stroke-linecap="round"/></g>
    <g><circle cx="215" cy="226" r="17" fill="#f58aa8" stroke="#c9577b" stroke-width="3"/><path d="M203 220 q12 10 24 0 M205 230 q10 6 20 -2" stroke="#c9577b" stroke-width="2.5" fill="none"/></g>
   </svg>
   <span class="cat-name"><?=e(t('dash.cat_name'))?></span><span class="cat-love" id="catLove">♥ 0</span>
   <div class="cat-bubble" id="catBubble"><?=e(t('dash.cat_bubble'))?></div>
   <div class="cat-wrap" id="catWrap"><svg class="cat" id="cat" viewBox="0 0 220 220" aria-label="<?=e(t('dash.cat_aria'))?>">
    <g class="tail"><path d="M158 182 C204 176 208 132 188 112" fill="none" stroke="#2b2230" stroke-width="17" stroke-linecap="round"/><path d="M158 182 C204 176 208 132 188 112" fill="none" stroke="#fff3df" stroke-width="9" stroke-linecap="round"/></g>
    <g class="body"><path d="M58 196 C48 140 72 118 110 118 C148 118 172 140 162 196 Z" fill="#fff3df" stroke="#2b2230" stroke-width="5" stroke-linejoin="round"/><path d="M70 142 q9 4 11 15 M150 142 q-9 4 -11 15" stroke="#c98a55" stroke-width="5" stroke-linecap="round" fill="none"/><ellipse cx="88" cy="194" rx="17" ry="9" fill="#fff3df" stroke="#2b2230" stroke-width="5"/><ellipse cx="132" cy="194" rx="17" ry="9" fill="#fff3df" stroke="#2b2230" stroke-width="5"/></g>
    <g class="head"><path d="M62 82 L56 36 L96 62 Z" fill="#fff3df" stroke="#2b2230" stroke-width="5" stroke-linejoin="round"/><path d="M67 70 L65 50 L83 62 Z" fill="#f7b6bf"/><path d="M158 82 L164 36 L124 62 Z" fill="#fff3df" stroke="#2b2230" stroke-width="5" stroke-linejoin="round"/><path d="M153 70 L155 50 L137 62 Z" fill="#f7b6bf"/>
     <ellipse cx="110" cy="100" rx="56" ry="46" fill="#fff3df" stroke="#2b2230" stroke-width="5"/>
     <path d="M110 57 v14 M95 61 l3 11 M125 61 l-3 11" stroke="#c98a55" stroke-width="5" stroke-linecap="round"/>
     <g class="eyes-open"><ellipse cx="88" cy="102" rx="6" ry="8" fill="#2b2230"/><ellipse cx="132" cy="102" rx="6" ry="8" fill="#2b2230"/><circle cx="90" cy="99" r="2.3" fill="#fff"/><circle cx="134" cy="99" r="2.3" fill="#fff"/></g>
     <g class="eyes-closed"><path d="M79 104 q9 -10 18 0 M123 104 q9 -10 18 0" stroke="#2b2230" stroke-width="4.5" fill="none" stroke-linecap="round"/></g>
     <ellipse cx="72" cy="117" rx="9" ry="5.5" fill="#f7a8b4" opacity=".7"/><ellipse cx="148" cy="117" rx="9" ry="5.5" fill="#f7a8b4" opacity=".7"/>
     <path d="M106 112 h8 l-4 5 z" fill="#f08aa0"/><path d="M110 117 v4 M110 121 q-6 6 -12 1 M110 121 q6 6 12 1" stroke="#2b2230" stroke-width="3.5" fill="none" stroke-linecap="round"/>
     <path d="M58 112 l-22 -5 M58 121 l-22 4 M162 112 l22 -5 M162 121 l22 4" stroke="#2b2230" stroke-width="2.5" stroke-linecap="round"/></g>
   </svg></div>
  </section>
  <h2 class="yen-section-title"><?=e(t('dash.sleep_h'))?></h2>
  <section class="yen-sleep-row">
   <div class="yen-sleep-card sleep-calc"><div class="sleep-stars">✦　✧　✦</div><div class="sleep-moon">☾</div><div class="sleep-ring" id="sleepRing"><div class="sleep-ring-in"><b id="sleepHours">--</b><small id="sleepSub"><?=e(t('dash.sleep_now'))?></small></div></div><div class="sleep-right"><label class="wake-label"><?=e(t('dash.wake'))?><input type="time" id="wakeTime" value="07:00"></label><div class="bed-title"><?=e(t('dash.bed_best'))?></div><div class="bed-chips" id="bedChips"></div><p class="sleep-msg" id="sleepMsg"></p></div></div>
   <div class="yen-tip-card"><span>✧</span><h3><?=e(t('dash.tip_h'))?></h3><p><?=e($personalTip)?></p><a href="add.php"><?=e(t('dash.tip_link'))?></a></div>
  </section>
  <section class="quote-card is-<?=$gender==='male'?'male':'female'?>"><div class="quote-mark">❝</div><div class="quote-body"><small><?=e(t($gender==='male'?'dash.q_m':'dash.q_f'))?></small><p id="quoteText"><?=e($quotes[$qi])?></p></div><button type="button" id="quoteBtn" data-q='<?=e(json_encode($quotes,JSON_UNESCAPED_UNICODE))?>' data-i="<?=$qi?>"><?=e(t('dash.q_more'))?></button></section>
  <div class="yen-share-head"><h2 class="yen-section-title"><?=e(t('dash.share_h'))?></h2><a href="history.php"><?=e(t('dash.all'))?></a></div>
  <section class="yen-share-card"><div><strong><?=e(t('dash.share_t'))?></strong><p><?=e(t('dash.share_p'))?></p></div><a class="yen-add-button" href="add.php"><?=e(t('dash.add_btn'))?></a></section>
  <section class="yen-recent"><div class="yen-share-head"><h2 class="yen-section-title"><?=e(t('dash.recent_h'))?></h2><a href="history.php"><?=e(t('dash.see_all'))?></a></div>
   <?php if(!$recent):?><div class="yen-empty"><?=e(t('dash.empty'))?></div><?php else:foreach($recent as $r):?><article class="yen-recent-item"><span><?=mood_face($r['mood'])?></span><div><b><?=e(mood_name($r['mood']))?></b><small><?=e($r['note']?:t('dash.memory'))?></small></div><time><?=e(date('d.m.Y',strtotime($r['entry_date'])))?></time></article><?php endforeach;endif;?>
  </section>
 </main>
 <aside class="yen-side-column">
  <?php include 'inc_weather.php'; ?>
  <section class="yen-calendar-card"><div class="calendar-heading"><button type="button" id="calPrev" aria-label="<?=e(t('dash.prev_m'))?>">‹</button><strong id="calMonth"></strong><button type="button" id="calNext" aria-label="<?=e(t('dash.next_m'))?>">›</button></div><div class="calendar-week"><?php foreach(explode(',',t('dash.wd')) as $wd):?><span><?=e($wd)?></span><?php endforeach;?></div><div class="calendar-days" id="calendarDays"></div><a class="calendar-link" href="history.php"><?=e(t('dash.cal_link'))?></a><div class="cal-cat" aria-hidden="true"><svg class="cal-cat-svg" viewBox="0 0 122 112" aria-hidden="true"><path d="M84 100C110 98 110 66 92 62" fill="none" stroke="#2b2230" stroke-width="15" stroke-linecap="round"/><path d="M84 100C110 98 110 66 92 62" fill="none" stroke="#fff" stroke-width="8" stroke-linecap="round"/><ellipse cx="55" cy="90" rx="31" ry="22" fill="#fff" stroke="#2b2230" stroke-width="4"/><ellipse cx="41" cy="106" rx="10" ry="6" fill="#fff" stroke="#2b2230" stroke-width="4"/><ellipse cx="69" cy="106" rx="10" ry="6" fill="#fff" stroke="#2b2230" stroke-width="4"/><path d="M26 38L23 10L49 27Z" fill="#fff" stroke="#2b2230" stroke-width="4" stroke-linejoin="round"/><path d="M84 38L87 10L61 27Z" fill="#fff" stroke="#2b2230" stroke-width="4" stroke-linejoin="round"/><path d="M29 31L28 18L40 26Z" fill="#f7b6bf"/><path d="M81 31L82 18L70 26Z" fill="#f7b6bf"/><path d="M23 48L11 51L20 57L10 63L23 65" fill="#fff" stroke="#2b2230" stroke-width="3.5" stroke-linejoin="round"/><path d="M87 48L99 51L90 57L100 63L87 65" fill="#fff" stroke="#2b2230" stroke-width="3.5" stroke-linejoin="round"/><ellipse cx="55" cy="52" rx="34" ry="28" fill="#fff" stroke="#2b2230" stroke-width="4"/><path d="M55 26v7M47 28l2 6M63 28l-2 6" stroke="#e6cdb8" stroke-width="3.5" stroke-linecap="round"/><ellipse cx="42" cy="54" rx="4.5" ry="6" fill="#2b2230"/><ellipse cx="68" cy="54" rx="4.5" ry="6" fill="#2b2230"/><circle cx="43.5" cy="52" r="1.8" fill="#fff"/><circle cx="69.5" cy="52" r="1.8" fill="#fff"/><ellipse cx="31" cy="64" rx="6.5" ry="4" fill="#f7a8b4" opacity=".75"/><ellipse cx="79" cy="64" rx="6.5" ry="4" fill="#f7a8b4" opacity=".75"/><path d="M52 62h6l-3 4z" fill="#f08aa0"/><path d="M55 66v3M55 69q-5 5-9 1M55 69q5 5 9 1" stroke="#2b2230" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M30 60l-12-3M30 66l-12 3M80 60l12-3M80 66l12 3" stroke="#2b2230" stroke-width="2" stroke-linecap="round"/></svg></div></section>
  <section class="yen-weather-card"><div class="weather-sky">☾ ☁</div><div class="weather-label"><?=e(t('dash.yourday'))?></div><strong class="weather-number"><?=e($stats['total']?'♡':'✧')?></strong><h3><?=e(isset($top['mood'])?mood_name($top['mood']):t('dash.newday'))?></h3><p><?=e(t('dash.last7'))?></p><div class="weather-details"><span>✎ <?=e(t('ins.total'))?> <b><?= (int)$stats['total']?></b></span><span>♡ <?=e(t('ins.avg'))?> <b><?=$stats['avgscore']?number_format($stats['avgscore'],1):'—'?> / 5</b></span></div><div class="weather-bottom"><div><small><?=e(t('dash.w_self'))?></small><b><?=e(t('dash.w_care'))?></b></div><div><small><?=e(t('dash.w_today'))?></small><b><?=date('d.m')?></b></div><div><small><?=e(t('dash.w_diary'))?></small><b>♡</b></div></div></section>
 </aside>
</div>
<script>
(()=>{const days=document.getElementById('calendarDays'),label=document.getElementById('calMonth');if(!days)return;let view=new Date();view.setDate(1);const today=new Date();const months=<?=json_encode(explode(',',t('mon.full')),JSON_UNESCAPED_UNICODE|JSON_HEX_TAG)?>;function draw(){label.textContent=months[view.getMonth()]+' '+view.getFullYear();days.innerHTML='';const first=(view.getDay()+6)%7,total=new Date(view.getFullYear(),view.getMonth()+1,0).getDate();for(let i=0;i<first;i++){const s=document.createElement('span');s.className='empty-day';days.append(s)}for(let d=1;d<=total;d++){const b=document.createElement('a');b.textContent=d;b.href='add.php?date='+view.getFullYear()+'-'+String(view.getMonth()+1).padStart(2,'0')+'-'+String(d).padStart(2,'0');if(d===today.getDate()&&view.getMonth()===today.getMonth()&&view.getFullYear()===today.getFullYear())b.classList.add('today');days.append(b)}}document.getElementById('calPrev').onclick=()=>{view.setMonth(view.getMonth()-1);draw()};document.getElementById('calNext').onclick=()=>{view.setMonth(view.getMonth()+1);draw()};draw()})();
</script>
<script>(()=>{const b=document.getElementById('quoteBtn');if(!b)return;const q=JSON.parse(b.dataset.q);let i=+b.dataset.i;const t=document.getElementById('quoteText');b.addEventListener('click',()=>{i=(i+1)%q.length;t.style.opacity=0;setTimeout(()=>{t.textContent=q[i];t.style.opacity=1},180)})})();</script>
<script>
(()=>{const L=<?=json_encode(['now'=>t('dash.sleep_now'),'at'=>t('dash.sleep_2230'),'h'=>t('dash.h'),'min'=>t('dash.min'),'h9'=>t('dash.hrs9'),'h75'=>t('dash.hrs75'),'h6'=>t('dash.hrs6'),'s0'=>t('dash.sl0'),'s1'=>t('dash.sl1'),'s2'=>t('dash.sl2'),'s3'=>t('dash.sl3'),'s4'=>t('dash.sl4')],JSON_UNESCAPED_UNICODE|JSON_HEX_TAG)?>;const wt=document.getElementById('wakeTime');if(!wt)return;
try{const s=localStorage.getItem('wakeTime:'+window.YEN_UID);if(s)wt.value=s}catch(e){}
const ring=document.getElementById('sleepRing'),hrs=document.getElementById('sleepHours'),chips=document.getElementById('bedChips'),msg=document.getElementById('sleepMsg');
const pad=n=>String(n).padStart(2,'0'),fmt=d=>pad(d.getHours())+':'+pad(d.getMinutes());
function wakeDate(){const[h,m]=(wt.value||'07:00').split(':').map(Number);const d=new Date();d.setHours(h,m,0,0);if(d<=new Date())d.setDate(d.getDate()+1);return d}
function draw(){const now=new Date(),w=wakeDate();let start=now,lab=L.now;if(now.getHours()>=5&&now.getHours()<20){start=new Date();start.setHours(22,30,0,0);lab=L.at}document.getElementById('sleepSub').textContent=lab;const sleepMin=Math.max(0,Math.round((w-start)/60000)-15);const h=Math.floor(sleepMin/60),m=sleepMin%60;
 hrs.textContent=h+' '+L.h+' '+pad(m)+' '+L.min;ring.style.setProperty('--deg',Math.min(sleepMin/540,1)*360+'deg');
 const hh=sleepMin/60;msg.textContent=hh<5?L.s0:hh<6.5?L.s1:hh<7.5?L.s2:hh<=9.5?L.s3:L.s4;
 chips.innerHTML='';[[6,L.h9],[5,L.h75],[4,L.h6]].forEach(([c,l])=>{const b=new Date(w.getTime()-(c*90+15)*60000);const el=document.createElement('span');el.className='bed-chip'+(c===5?' best':'');el.innerHTML='<b>'+fmt(b)+'</b><small>'+l+(c===5?' ⭐':'')+'</small>';chips.append(el)})}
wt.addEventListener('input',()=>{try{localStorage.setItem('wakeTime:'+window.YEN_UID,wt.value)}catch(e){}draw()});draw();setInterval(draw,30000);})();
(()=>{const wrap=document.getElementById('catWrap');if(!wrap)return;const CATB=<?=json_encode(t('dash.cat_bubble'),JSON_UNESCAPED_UNICODE|JSON_HEX_TAG)?>;const cat=document.getElementById('cat'),card=document.getElementById('catCard'),bubble=document.getElementById('catBubble'),love=document.getElementById('catLove');
let n=0;try{n=+localStorage.getItem('catLove:'+window.YEN_UID)||0}catch(e){}love.textContent='♥ '+n;
const talk=<?=json_encode(explode('|',t('dash.cat_talk')),JSON_UNESCAPED_UNICODE|JSON_HEX_TAG)?>;
let dist=0,last=null,off=null,ti=0;
function heart(){const h=document.createElement('span');h.className='cat-heart';h.textContent=['💗','💛','🤍','💜'][Math.floor(Math.random()*4)];const r=wrap.getBoundingClientRect(),c=card.getBoundingClientRect();h.style.left=(r.left-c.left+r.width/2+(Math.random()*90-45))+'px';h.style.top=(r.top-c.top+30)+'px';card.append(h);setTimeout(()=>h.remove(),1500)}
function stroke(){n++;love.textContent='♥ '+n;try{localStorage.setItem('catLove:'+window.YEN_UID,n)}catch(e){}cat.classList.add('purr');bubble.textContent=talk[ti++%talk.length];bubble.classList.add('show');heart();try{navigator.vibrate&&navigator.vibrate(8)}catch(e){}clearTimeout(off);off=setTimeout(()=>{cat.classList.remove('purr');bubble.textContent=CATB},1500)}
wrap.addEventListener('pointermove',e=>{if(last){dist+=Math.hypot(e.clientX-last.x,e.clientY-last.y);if(dist>60){dist=0;stroke()}}last={x:e.clientX,y:e.clientY}});
wrap.addEventListener('pointerleave',()=>{last=null;dist=0});
wrap.addEventListener('pointerdown',e=>{last={x:e.clientX,y:e.clientY};cat.classList.remove('poke');void cat.getBoundingClientRect();cat.classList.add('poke');stroke()});
bubble.classList.add('show');})();
</script>
<?php require 'inc_footer.php'; ?>
