<?php
$jq=db()->prepare('SELECT id,mood,note,entry_date FROM mood_entries WHERE user_id=? ORDER BY entry_date DESC,id DESC LIMIT 48');$jq->execute([$uid]);$jrows=array_reverse($jq->fetchAll());
$jm=array_map(fn($x)=>[$x['emoji'],$x['jar']],mood_registry());
$jdata=array_map(fn($r)=>['m'=>$r['mood'],'e'=>mood_face($r['mood'],'🙂'),'c'=>$jm[$r['mood']][1]??'#b8a7e5','d'=>date('d.m.Y',strtotime($r['entry_date'])),'mn'=>mood_name($r['mood']),'n'=>$r['note']?:t('note.default')],$jrows);
$cnt=[];foreach($jdata as $x){$cnt[$x['m']]=($cnt[$x['m']]??0)+1;}arsort($cnt);$tot=max(1,count($jdata));$orbStops=[];$acc=0;foreach($cnt as $m=>$n){$orbStops[]=($jm[$m][1]??'#ccc').' '.round($acc).'%';$acc+=$n/$tot*100;$orbStops[]=($jm[$m][1]??'#ccc').' '.round($acc).'%';}
?>
<section class="jar-section">
 <div class="jar-head"><h2><?=e(t('jar.title'))?></h2><p><?=e(t('jar.sub'))?></p></div>
 <div class="jar-layout">
  <div class="jar-stage">
   <div class="jar" id="jar"><div class="jar-lid"></div><div class="jar-neck"></div><div class="jar-glass" id="jarGlass"><div class="jar-shine"></div></div></div>
   <button type="button" class="jar-shake" id="jarShake"><?=e(t('jar.shake'))?></button>
  </div>
  <div class="jar-side">
   <div class="orb-card"><div class="orb" style="<?=$jdata?'background:conic-gradient(from 20deg,'.e(implode(',',$orbStops)).')':''?>"></div><div><b><?=e(t('jar.mix_h'))?></b><small><?=e(t('jar.mix_sub'))?></small><div class="orb-pcts"><?php $i=0;foreach($cnt as $m=>$n):if($i++>=4)break;?><span><i style="--c:<?=e($jm[$m][1]??'#ccc')?>"><?=mood_face($m,'🙂')?></i><?=round($n/$tot*100)?>%</span><?php endforeach;?><?php if(!$cnt):?><span><i style="--c:#ccc"><?=mood_face('Қалыпты','🙂')?></i>0%</span><?php endif;?></div></div></div>
   <div class="note-card" id="noteCard"><div class="note-ball" id="noteBall">🫧</div><div class="note-text"><b id="noteMood"><?=e($jdata?t('jar.tap'):t('jar.empty'))?></b><small id="noteDate"><?=e($jdata?t('jar.tap_sub'):t('jar.empty_sub'))?></small><p id="noteBody"><?=$jdata?'':e(t('jar.empty_body'))?></p></div></div>
   <a class="jar-add" href="add.php"><?=e(t('jar.add'))?></a>
  </div>
 </div>
</section>
<script>
(()=>{const data=<?=json_encode($jdata,JSON_UNESCAPED_UNICODE)?>;const glass=document.getElementById('jarGlass'),jar=document.getElementById('jar');
const nb=document.getElementById('noteBall'),nm=document.getElementById('noteMood'),nd=document.getElementById('noteDate'),nt=document.getElementById('noteBody');
const D=38,GAP=3,W=240,H=300;let balls=[];
function shade(h,a){const n=parseInt(h.slice(1),16);let r=(n>>16)+a,g=((n>>8)&255)+a,b=(n&255)+a;const c=v=>Math.max(0,Math.min(255,v));return 'rgb('+c(r)+','+c(g)+','+c(b)+')'}
function paint(el,x){el.style.background='radial-gradient(circle at 32% 26%,#fff 0,'+shade(x.c,70)+' 22%,'+x.c+' 62%,'+shade(x.c,-45)+' 100%)'}
function show(i){const x=data[i];if(!x)return;balls.forEach(b=>b.classList.remove('sel'));balls[i].classList.add('sel');nb.innerHTML=x.e;paint(nb,x);nm.textContent=x.mn;nd.textContent=x.d;nt.textContent=x.n}
function build(){glass.querySelectorAll('.ball').forEach(b=>b.remove());balls=[];const perEven=Math.floor((W-6)/(D+GAP)),perOdd=perEven-1;let row=0,col=0;
 data.forEach((x,i)=>{const per=row%2?perOdd:perEven;if(col>=per){row++;col=0}const off=(row%2?(D+GAP)/2:0);const jx=((i*37)%5)-2,jy=((i*53)%5)-2;
  const left=(W-6-perEven*(D+GAP)+GAP)/2+4+col*(D+GAP)+off+jx;const bottom=6+row*(D-2)+jy;col++;
  const el=document.createElement('button');el.type='button';el.className='ball';el.innerHTML=x.e;el.style.left=left+'px';el.style.bottom=bottom+'px';el.style.setProperty('--fall',(H-bottom+60)+'px');el.style.setProperty('--dl',(i*45+Math.random()*120)+'ms');paint(el,x);
  el.addEventListener('click',()=>show(i));glass.append(el);balls.push(el)});
 if(data.length)show(data.length-1)}
build();
document.getElementById('jarShake').addEventListener('click',()=>{jar.classList.remove('shake');void jar.offsetWidth;jar.classList.add('shake');build()});
})();
</script>
