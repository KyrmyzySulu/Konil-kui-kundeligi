CREATE DATABASE IF NOT EXISTS mood_journal CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mood_journal;
CREATE TABLE IF NOT EXISTS users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(80) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 avatar VARCHAR(255) NULL,
 gender ENUM('female','male') NOT NULL DEFAULT 'female',
 role ENUM('user','admin') NOT NULL DEFAULT 'user'
);
CREATE TABLE IF NOT EXISTS mood_entries (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 mood VARCHAR(30) NOT NULL,
 score TINYINT UNSIGNED NOT NULL,
 note TEXT NULL,
 category VARCHAR(60) NULL,
 entry_date DATE NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_entries_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_user_date (user_id, entry_date)
);

CREATE TABLE IF NOT EXISTS user_status (
 user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
 data TEXT NOT NULL,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_status_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Кіру әрекеттерін шектеу (brute-force қорғанысы)
CREATE TABLE IF NOT EXISTS login_attempts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 ip VARCHAR(45) NOT NULL,
 email VARCHAR(190) NOT NULL,
 attempted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_ip_time (ip, attempted_at),
 INDEX idx_email_ip_time (email, ip, attempted_at)
);

-- Бұрыннан бар дерекқорға жаңарту қажет болса, төмендегі командаларды бір рет орындаңыз:
-- ALTER TABLE users ADD COLUMN avatar VARCHAR(255) NULL,
 gender ENUM('female','male') NOT NULL DEFAULT 'female', ADD COLUMN role ENUM('user','admin') NOT NULL DEFAULT 'user';
-- ALTER TABLE mood_entries ADD COLUMN category VARCHAR(60) NULL;
